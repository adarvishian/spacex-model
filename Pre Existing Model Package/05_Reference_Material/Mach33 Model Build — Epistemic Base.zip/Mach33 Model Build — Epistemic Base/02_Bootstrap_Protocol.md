# Bootstrap Protocol — Starting a New Mach33 Model from Scratch

**When to use this**: At the start of any new Mach33 modular valuation model build (Portal, ASTS, next SpaceX iteration, anything new). Also at the start of any *rebuild* of an existing model that has accumulated load-bearing drift.

**What this is**: The five-document bootstrap that must exist in the project folder before Sprint 1 runs. The rule is non-negotiable: sprints do not begin until all five are drafted, reviewed, and locked. This is the single biggest lesson from the V30.5 build (see `01_The_Epistemic_Base.md`, Meta-lesson 1).

---

## The five constitutional documents

| # | Doc | Purpose | Status |
|---|-----|---------|--------|
| 00 | `00_README_Sprint_Kickoff.md` | Navigation + protocol + kickoff prompt template | Authoritative entry point |
| 01 | `01_Lessons_Learned.md` | The 23 principles (WHY) — each tied to a specific prior-build incident | Constitutional |
| 02 | `02_Architecture_and_Methodology.md` | Structural design + math conventions (WHAT + HOW) | Constitutional |
| 03 | `03_Sprint_Roadmap_and_Verification.md` | Sprint phase plan + per-sprint acceptance criteria (WHEN) | Constitutional |
| 04 | `04_Assumptions_Tab_Spec.md` (+ optional Build Plan XLSX) | Cell-by-cell input plan (INPUTS) | Constitutional |

Plus `Model Execution Rules.md` — the 23 plugin-side operational rules + the Rule Compliance Preamble template (see `04_Model_Execution_Rules.md` in this folder, or use the verbatim copy in `reference/`).

For most new builds, copy the corresponding docs from `reference/` and adapt — the structural skeleton is reusable across companies.

---

## Bootstrap checklist (in order)

### Step 1 — Scoping conversation with Vlad (or the model owner)

Before any docs get drafted, answer these questions explicitly with the owner. None of these can be deferred. If an answer is "we will figure it out later", the build has already started the failure mode that destroyed V30.5.

1. **What is being built?** Company name, modelling horizon (typically 25 years out, columns D:AC for 2025–2050), and the deadline.
2. **Predecessor / reference workbook?** Most builds inherit from a prior model (V30.5 for SpaceX, the Mach33 Portal model for Portal, etc.). The predecessor provides historical anchors and architectural inspiration — never a starting point to be refined.
3. **Module list.** Which tabs exist. For SpaceX rebuild v2: Assumptions, Allocator, Launch Capacity, Customer Launch, Starlink, Starlink Capacity, ODC, AI Stack, Lunar Mars, Group P&L, OpEx, CapEx, Valuation, Claude Log. No Dashboard. No ISM. Demand Curves if needed.
4. **P&L structure.** Vending-machine (every module: Revenue → COGS → Gross Profit = Module EBITDA → CapEx → Module FCF) unless there is a specific reason to deviate. R&D, SG&A, corporate overhead, taxes live at Group / OpEx only.
5. **IRR engine scope.** Which modules get an IRR engine? Per-unit marginal IRR (per-sat, per-launch) for any deployable-unit module. Strategic carve-outs (Moon/Mars equivalent) get NO IRR engine — deducted from cash pool before queue runs.
6. **Allocator architecture.** Cash pool + queue gate + IRR-priority sigmoid blend. Non-module claims (OpEx, Corp CapEx, Spectrum, Taxes, strategic carve-out) reserved before module CapEx allocation. Within-year cycles documented and justified.
7. **Calibration anchors.** The latest disclosed financials (Q4, 10-K, S-1, funding round disclosure) for the most recent full year. Locked as the 2025 (or year-zero) target table. Every sprint must hit its anchors within ±5%.
8. **Year horizon.** Locked. Year header row, year-offset helper row position.
9. **Cross-tab discipline.** INDEX/MATCH on canonical labels everywhere. Zero `OFFSET()`. Anchor-and-offset for ramps. Allocator OUT contract fixes the canonical labels.
10. **Monte Carlo posture.** Build with point estimates. MC ranges layered at end on every Assumptions input. Scenarios are POST-MC conditional cuts, not pre-MC point estimates.

Each answer goes into the constitutional doc that owns the topic. If the owner cannot answer a question, the bootstrap halts until they can.

### Step 2 — Draft `01_Lessons_Learned.md`

The lessons doc captures *why* the operational rules exist. For a new model, this is largely portable from the SpaceX rebuild — the 23 principles are about how to direct AI to build a complex Excel model, not about SpaceX specifically.

Three options:
- **New model in a familiar shape (Portal, ASTS)**: Copy `reference/01_Lessons_Learned_FULL.md` verbatim (drop the `_FULL` suffix when staging in the new model's folder). The 23 principles apply. Add a one-paragraph preamble noting the predecessor.
- **New model in a meaningfully different shape**: Copy the SpaceX version, then prune principles that don't apply and add company-specific ones at the end.
- **Total greenfield (no analog)**: Use the SpaceX version as a template and rewrite. Most principles will still apply but the incident citations will be from the new model's bootstrap conversation.

Whichever path, the doc must end with an Amendment Log section that gets updated every time the doc is touched.

### Step 3 — Draft `02_Architecture_and_Methodology.md`

This is the long one. Contains:

- **Tab list** with one-paragraph function statement per tab
- **Module P&L structure** (the vending-machine framing, made concrete with the specific module list)
- **Allocator OUT contract** — the canonical row labels every module tab must expose
- **IRR engine specification** — per-unit marginal IRR formula, Spot/Forward Y+2/Blended weights, queue cutoff rule
- **Cash pool tracker** — Cash BoY formula, IPO injections, queue gate formula
- **Strategic carve-out** (if applicable) — sizing rule, MC ranges, deduction order
- **IRR-priority sigmoid blend** — formula, exponent k, application to cash and capacity queues
- **Deployment formula** — MIN(cash, capacity, internal demand)
- **Internal transfers** — at-cost discipline, elimination at Group, conservation check
- **Vehicle/launch build cost** (if applicable) — forward-aggregate demand sizing, non-module claim location
- **Year-offset helper row** + **Year header** position on every tab
- **Iterative calc settings** — on, iteration count, tolerance, 5x round-trip stability test as part of every verification gate

For the SpaceX rebuild this document is ~58KB. Most of that bulk is portable. Use `reference/02_Architecture_and_Methodology_FULL.md` as the starting point.

### Step 4 — Draft `03_Sprint_Roadmap_and_Verification.md`

Lists the sprint sequence with per-sprint scope, dependencies, acceptance criteria, and the universal verification protocol. The SpaceX rebuild has 12 sprints; new models may have fewer or more depending on tab count.

Standard sprint template (adapt to module list):
- **Sprint 0**: Architecture spec + Assumptions tab skeleton + tab list written to workbook
- **Sprint 1**: Assumptions tab populated (all rows, all base case values, all MC ranges)
- **Sprint 2–N**: Module sprints, one module per sprint
- **Sprint N+1**: Cross-cutting tabs (OpEx, CapEx aggregation)
- **Sprint N+2**: Allocator (cash + capacity queues, queue gate, internal flows)
- **Sprint N+3**: Group P&L (consolidation, eliminations, conservation checks)
- **Sprint N+4**: Valuation (DCF, terminal value, SoTP if relevant)
- **Sprint N+5**: Monte Carlo
- **Sprint N+6**: Scenarios

Plus the **universal verification protocol** — see `07_Calibration_and_Verification.md` for the full version.

### Step 5 — Draft `04_Assumptions_Tab_Spec.md`

Cell-by-cell input plan. The Assumptions tab has 7 columns:

1. Cell ref (e.g. `B14`)
2. Label
3. Base Case value (point estimate)
4. MC Min
5. MC Max
6. MC Distribution (triangle / lognormal / uniform / discrete)
7. Notes (source, calibration anchor, "structural — no MC" flag if applicable)

Every input is populated at creation with its MC range. No retrofitting. The MC sprint wires the engine against an already-complete register; it does not back-fill.

For new models, the Assumptions register typically has 200–500 rows. The Build Plan XLSX is optional — for the SpaceX rebuild we shipped both a markdown wrapper and an executable XLSX that the plugin reads against directly. For new models with fewer inputs, inline the table in the markdown.

### Step 6 — Lock and stage

Once all five docs are drafted:

1. Have the owner read them end-to-end. The owner is the one signing off that the architecture is right.
2. Push back on any "we will figure this out later" responses. Each one is a future retrofit cascade.
3. Stage the docs in the project folder. The folder structure for the SpaceX rebuild:

```
/Users/[user]/Documents/Claude/Projects/[Model Name]/
├── 00_README_Sprint_Kickoff.md              ← read first, every sprint
├── 01_Lessons_Learned.md                     ← constitutional
├── 02_Architecture_and_Methodology.md        ← constitutional
├── 03_Sprint_Roadmap_and_Verification.md     ← constitutional
├── 04_Assumptions_Tab_Spec.md                ← constitutional (wrapper)
├── 04_Assumptions_Tab_Build_Plan.xlsx        ← constitutional (executable, optional)
├── Model Execution Rules.md                  ← supporting (mandatory ref)
├── [Year] Anchors from [Source].md           ← supporting (calibration targets)
├── Stale_Row_Map.md                          ← supporting (if rebuild, what to AVOID re-introducing)
├── [Predecessor model].xlsx                  ← reference (the old model)
└── archive/legacy-build-[dates]/             ← superseded specs from the predecessor
```

4. Mount the project folder in the Cowork session so Claude can read it.
5. Open the first sprint chat with the kickoff prompt template (see `06_Sprint_Spec_Template.md`).

---

## The rebuild-from-scratch vs refine decision

If you are starting from an existing model rather than greenfield, the first decision is: rebuild or refine?

**Rebuild from scratch** when:
- The existing model has accumulated load-bearing methodology drift across 10+ specs (vending-machine retrofit, IRR engine refactor, allocator restructure, OFFSET purge, etc.)
- The stale residue map exceeds ~200 cells
- The owner has lost confidence in the existing model's outputs
- A planned change touches the entire workbook architecture (e.g., adding a new top-level concept like a strategic carve-out)

**Refine** when:
- The architectural skeleton is sound and the planned change is bounded to 1–3 tabs
- Calibration is broadly hitting; the change is to update assumptions or add a new sub-component
- The owner has confidence in the existing model and just wants a layer added

The SpaceX V30.5 → Rebuild v2 transition is the canonical rebuild case. Vlad's exact framing on 2026-05-19: "I'm getting stressed out, there's so much stale shit in it." When the owner has lost confidence, rebuild. The cost of rebuilding is bounded; the cost of accumulating further drift is not.

For the full decision rule with the V30.5 case study, see `09_When_To_Rebuild_vs_Refine.md`.

---

## What changes for the second sprint and beyond

Once Sprint 0 lands, Sprint 1 onwards follows the standard workflow:

1. Spec author chat opens with the kickoff prompt template, reads the five constitutional docs (or invokes the `mach33-model-build` skill, which embeds them), drafts `Sprint_N_Spec.md` with the Rule Compliance Preamble at the top.
2. Owner reviews the spec.
3. Fresh plugin execution chat opens with the kickoff prompt template, reads only the spec, refuses to start if the preamble is unchecked, executes the writes against the live workbook, runs the verification gates, appends a row to the Claude Log tab.
4. Owner reviews the calibration results. PASS → move to next sprint. FAIL → diagnose, write a patch sprint (Sprint N.5), repeat.

The constitutional docs do not change during this loop. They get amended (with an Amendment Log entry) only when a sprint surfaces an architectural fact that the docs got wrong — and the amendment happens *before* the next sprint runs, not in the middle of one.

---

## Common bootstrap failure modes

These are the ways the bootstrap goes wrong in practice. Watch for each.

1. **"Let's just start with Sprint 1 and figure out the architecture as we go."** No. This is V30.5. The architecture spec must exist first.
2. **"We will lock the IRR engine when we get to that module."** No. The IRR formulation affects how every module's P&L is structured. Lock it in the architecture spec.
3. **"The calibration anchors are not final yet, we will retune later."** No. Anchors lock pre-build. If the anchors change, the model rebuilds against the new anchors.
4. **"AI Stack vs ODC, we will resolve that when we get there."** No. Whether AI Stack is standalone or rolled into ODC affects the entire allocator architecture. Resolve in scoping.
5. **"Let's skip the Rule Compliance Preamble on the first spec, it is simple enough."** No. Every spec opens with the preamble. The discipline only works if it is unbroken.

When any of these come up in scoping, the answer is to slow down and answer the question now. The cost of answering now is hours; the cost of answering later is multiple sprints of retrofit.

---

## When the bootstrap is done

The bootstrap is complete when:

- All five constitutional docs exist in the project folder
- Owner has read and signed off on each
- Calibration anchor table is locked
- Architecture has the answers to all 10 scoping questions
- Sprint Roadmap lists the full sprint sequence with acceptance criteria
- Assumptions tab spec has every input planned with its MC range
- Project folder is mounted in the Cowork session
- The kickoff prompt template is ready to paste

At that point, Sprint 0 can run.

---

## Related

- `01_The_Epistemic_Base.md` — the meta-lessons that motivate this protocol
- `03_The_23_Lessons_Learned.md` — the principles, each tied to a V30.5 incident
- `04_Model_Execution_Rules.md` — the operational rules and Rule Compliance Preamble
- `05_Architecture_Patterns.md` — the architectural primitives the architecture doc must encode
- `06_Sprint_Spec_Template.md` — copy-paste starter spec
- `09_When_To_Rebuild_vs_Refine.md` — the decision rule
- `reference/` — full constitutional docs from the SpaceX rebuild as templates
- `skills/mach33-model-build-SKILL.md` — the skill that embeds the constitutional framework for any model build
