# The 23 Lessons Learned

**Source**: Synthesized from the 35-spec V30.5 build (Sprint 0 through Refine Spec 09) and the V26.1 deep audit. Each principle traces to a specific failure incident.

**Purpose**: This doc is the *why*. `04_Model_Execution_Rules.md` is the operational *what to do*. Where they overlap, this doc explains the failure that motivated each rule.

**Status**: Constitutional. Locked 2026-05-19. Amendable when a new load-bearing failure mode surfaces.

This is a distilled version. The verbatim constitutional doc lives in `reference/01_Lessons_Learned_FULL.md`.

---

## I. Architectural lockings — decide day one or pay a cascading retrofit cost

### Principle 1 — Postponed architectural decisions create retrofit cascades

Lock vending-machine framing, allocator circle, per-sat IRR, strategic carve-out, internal-transfer mechanics on day one in the architecture spec. Don't discover them through failure.

**Incident**: Vending-machine framing arrived at Refine Spec 01 — eleven days into the build. Every module tab had to be retrofitted to strip R&D, SG&A, corporate overhead, and taxes. Allocator circle closure arrived Spec 06+07 — Sprint 5's sigmoid + Layer 3 sweep had to be killed, rows R83-R104 cleared. Per-sat marginal IRR arrived Spec 08/09 — fleet-level MFW-IRR had to be retired. Three load-bearing methodologies, each requiring 3–5 sprints of retrofit.

### Principle 2 — Per-sat marginal IRR is the only IRR that works for pre-revenue modules

Every module with deployable units uses per-sat / per-launch marginal IRR computed from physics inputs, independent of current fleet count.

**Incident**: Fleet-level MFW-IRR trapped ODC at IRR = 0 forever. No fleet → no FCF → no IRR signal → no allocation → no fleet. Spec 08 Patch P and Spec 09 Patch M finally fixed by formulating IRR per marginal unit. The chicken-and-egg disappears because per-unit economics don't depend on fleet count.

### Principle 3 — Allocator IN/OUT contract is by label, not row number

Every cross-tab reference uses `INDEX(Module!D:D, MATCH("label", Module!$A:$A, 0))`. Zero hardcoded `=Module!Dxxx` row-number references anywhere.

**Incident**: Sprint 0 fixed every module's Allocator OUT block at rows 200–212. Sprint 3.5 inserted 8 rows on ODC. Every cross-tab reference using `=ODC!D210` silently pointed at the wrong concept. V26.1 audit Mistake M5 — Dashboard "Blended Starlink IRR" actually pulled Forward IRR because it was hardcoded at `Starlink!F209` when Blended sat at F210.

### Principle 4 — The cash queue reserves year-N non-module claims before module CapEx

Available cash for the IRR queue = `Cash BoY − Strategic carve-out − OpEx − Corp CapEx − Spectrum CapEx − Taxes`. Module CapEx allocation runs AFTER this subtraction.

**Incident**: Sprint 5's sigmoid distributed all available cash to modules by IRR weight, ignoring that year-N also needed funding for OpEx, Corporate CapEx, Spectrum acquisition (EchoStar), and Taxes. Modules could over-claim against a phantom capital pool. Spec 06+07 added the queue gate.

### Principle 5 — Strategic priority weights are not allocation mechanisms

The cash and capacity queues allocate by IRR-priority sigmoid blend. Strategic preferences encode through (a) which modules are in the queue at all, (b) the strategic carve-out off the top.

**Incident**: Sprint 0 introduced Strategic Priority Weights (5/4/3/2/1) for each module. Sprint 5 used them as floor multipliers in the sigmoid. Spec 06+07 retired the mechanism but kept the weight references "decorative." Three sprints' worth of mechanism for a concept that didn't survive the architecture review.

---

## II. Tab + naming discipline

### Principle 6 — Don't build a tab without a locked function

If a module's function isn't defined and load-bearing in the architecture spec, the tab doesn't exist.

**Incident**: ISM tab built Sprint 0, cut Sprint 5. Dashboard built Sprint 0 with charts, deleted 2026-05-19 after V26.1 audit found three bugs in its cross-tab pulls. AI Stack tab built as decorative skeleton, stayed dormant for 35 spec days. Each abandoned tab generated stale cross-tab refs that subsequent specs had to either route around or clean up.

### Principle 7 — Lock names day one; no renames mid-build

Every tab name, canonical row label, and key concept named in the architecture spec.

**Incident**: `Starship Capacity` → `Launch Capacity` (Sprint 2 rename — broke cross-tab refs that hadn't yet been INDEX/MATCH'd). `Launch` → `Customer Launch` (renamed 2026-05-19). Three different EBITDA labels coexisted on different module tabs: "True EBITDA" on Starlink, "EBITDA after corporate overhead" on Launch, "EBITDA-after-fleet-D&A" on ODC.

---

## III. Module conventions (vending-machine framing)

### Principle 8 — Module COGS contains direct production costs only — nothing else

Module P&L is `Revenue → COGS → Gross Profit = Module EBITDA → CapEx → Module FCF`. No R&D, SG&A, corporate overhead, taxes, or facilities D&A on any module tab.

**Incident**: Original Sprint 2–9 build placed R&D, SG&A, and corporate overhead allocation on every module tab. Refine Spec 01 killed all of it. But ODC R87 ("MOVED TO GROUP P&L — corporate overhead") retained live formulas computing $13,041M in 2030 (V26.1 M4). Violated the vending-machine framing structurally even though it didn't feed Allocator OUT.

### Principle 9 — Internal transfers count gross at module IRR; eliminate only at Group P&L

When module A buys from module B at-cost, module A books the cost in COGS (reduces A's IRR), module B books matching internal-transfer revenue (contributes to B's IRR). Group P&L eliminates the flow once so consolidated Revenue and FCF aren't double-counted.

**Incident**: Customer Launch ↔ Starlink launch services flow works correctly at module level — gross flows on each side, eliminated at Group. Sprint 7.5 routed Starship vehicle build cost INTO Customer Launch CapEx; Customer Launch's per-launch IRR distorted because it absorbed all vehicle build cost while only servicing some of the demand. Spec 09 fixed by pulling vehicle build out of Customer Launch entirely.

### Principle 10 — Module tabs are owned by module sprints; cross-cutting specs only read

A sprint that writes to a module tab is that module's sprint. Cross-tab aggregation specs (Group P&L, OpEx, CapEx, Valuation) read from module tabs but never write to them.

**Incident**: Sprint 5.6 introduced three helper rows per module (Cumulative CapEx, Cumulative D&A, Net Invested Capital) on each module tab. Refine Spec 02 then had to consolidate D&A reporting on the new CapEx tab while leaving the per-module D&A rows live. The architectural concept (separation between calculation owner and aggregation viewer) was sound but wasn't documented as a rule.

---

## IV. Formula patterns

### Principle 11 — Zero OFFSET formulas in the workbook, ever

Dynamic ranges use `INDEX(range, 1) : INDEX(range, N+1)` syntax. OFFSET is forbidden.

**Incident**: V28.1 had ~314 OFFSET cells across 5 module tabs. Spec 05 replaced all 314 with INDEX-based equivalents. Reasons OFFSET is bad: volatile (recalc on every cell change anywhere), fragile under row moves, opaque, doesn't compose with future Excel features.

### Principle 12 — Year-row formulas use anchor-and-offset, not recursive prior-column references

Pattern: `$D$anchor × (1+rate)^E$offset`. No `D_prev × (1+rate)` chains.

**Incident**: Original build chained year cells recursively. Row moves broke the chain. Spec 03 R&D and ODC R&D rows in V26 were stuck at start% across all years because copy-across step was skipped — recursive chain looked locally consistent at each cell but globally broken. Spec 03.2 introduced static-integer year-offset rows; ramp formulas became anchor-and-offset.

### Principle 13 — Year-offset helper row on every tab with year columns

Static integers 0 through N, located directly below the year-header row. Pattern: `D=0, E=1, ..., AC=25`. Hardcoded, not chained.

**Incident**: Originally Assumptions Row 11 was a recursive `=D11+1, =E11+1, ..., =AB11+1` chain. Spec 04 execution accidentally wiped Row 11, cascading #DIV/0! through Assumptions R241/R242 → ODC R22 → ODC R60 → ODC R64/R65/R73/R77/R82/R83/R84/R85 → Group P&L R108. Spec 06+07 Patch B replaced with hardcoded integers.

### Principle 14 — Cross-tab references via INDEX/MATCH on labels

Same as Principle 3, restated as a formula pattern. Codified as Rule 12.

---

## V. Execution discipline (plugin-side)

### Principle 15 — One concept per write; never mix labels, formulas, and formats

Separate tool calls for column-A labels, year-row formulas, number formats. Never combine in one `cells` dict.

**Incident**: Spec 03 execution disaster — a single `copyToRange` whose `cells` dict mixed column-A labels with column-D formulas. The tool interpreted the bounding box as the source pattern and tiled labels across column D, overwriting newly-written formulas. Cascaded to Bug 2 (R128 duplicate header) requiring Spec 03.1 patch.

### Principle 16 — `copyToRange` sources are single cells or single contiguous rows only

Non-contiguous source dicts have undefined tiling behavior.

**Incident**: Same Spec 03 incident as Principle 15. V26 had multiple corruption cases tied to non-contiguous source dicts.

### Principle 17 — Delete superseded rows in the same spec that supersedes them

When a methodology is superseded, the spec that supersedes it also deletes the prior rows. Never "leave for later cleanup."

**Incident**: Sprint 5 sigmoid superseded by Spec 06+07 → rows R20-R37 left in place with cleared formulas and `[Legacy — cleared]` labels. Layer 3 sweep superseded by Spec 06+07 → rows R83-R104 cleared but still present. Stale residue accumulated across 35 specs; the stale-map doc catalogues 200-400 cells likely still stale in V30.5. The user's frustration with stale residue motivated the entire rebuild decision.

### Principle 18 — MC ranges captured at input creation; never retrofitted

Every Assumptions input has its MC range column populated when the row is created. Either it's structural (no MC range, locked) or it's MC-tagged with `[min, max, distribution]` at creation.

**Incident**: Sprint 5.5 added 18 MC-variable inputs flagged for "MC register" → never registered. Sprint 5.6, 6, 7, 7.5, 8, 9 each added more, each deferred to "later housekeeping." Spec 08 Patch S was a narrow retroactive cleanup that still didn't catch everything. Net result in V30.5: no central source of truth for MC samples.

---

## VI. Verification discipline

### Principle 19 — Sanity check failures halt execution. No "proceed and document."

Every sanity check has a quantitative halt threshold. Failure = stop, push back to user with the failing check.

**Incident**: Spec 03 §4.2 included an explicit sanity check on implied DTC subscribers — "verify subs land in defensible range." V26 execution computed 22M implied DTC subs in 2025 (disclosed Starlink total subs ~5M, so 4× larger than total Starlink). Execution noted it, proceeded anyway. Bug survived into V26.1 audit (finding S5).

### Principle 20 — Read edge years (2025, 2030, 2040, 2050) at every verification gate

Every verification block reads at minimum columns D (2025), I (2030), S (2040), AC (2050). Never spot-check a single year.

**Incident**: Spec 03 R&D + ODC R&D rows in V26 were stuck at start% across all years because copy-across step was skipped. Mid-year-only verification didn't catch it — the start% values looked plausible at 2030.

### Principle 21 — Label-vs-source scan on every Allocator / Valuation pull

Every spec ends with a stale-reference scan: for every cross-tab cell that pulls `=Module!Cxx`, verify the source cell's column-A label matches the consumer's labeled concept.

**Incident**: V26.1 audit caught five material bugs that the Group P&L conservation block never flagged. Dashboard "Blended Starlink IRR" pulled `=Starlink!F209` (Forward IRR Y+2). Valuation "Live Group FCF" sourced from per-module FCFs (pre-tax) instead of Group FCF (post-tax). Valuation "Live Group D&A" pointed at Group FCF row D69.

### Principle 22 — Iterative-calc bistability is real; design within-year cycles deliberately

Every within-year cycle is documented in the architecture spec, justified, and verified to converge in <10 iterations. Break circularity with prior-year references where possible.

**Incident**: V28.1's saved state had Valuation D11 swing 4× across 6 sequential recalcs with no formula changes. Launch S91 IRR moved 0.206 → 0.210 across recalcs. Within-year cycles compounded under iterative calc. Model became non-deterministic across saves.

### Principle 23 — Calibration targets locked pre-build; outputs hit them within tolerance

Calibration targets locked before Sprint 1 of the rebuild. Every sprint that produces year-zero outputs must hit the targets within ±5%. Deviation triggers retune, not "proceed and audit later."

**Incident**: Original build had no anchored 2025 outputs. Sprint 11 ("audit") was supposed to retune Mars/Moon labour productivity to close the 10× BV undershoot vs spec target. But the spec target itself was speculative. No way to know if the model was right. User's confidence in V30.5 outputs was correspondingly low. The rebuild has Q4'25-anchored 2025 targets from day one.

---

## Open principles to flag

These are principles expected to emerge during the rebuild but without full incident-backing yet:

- **Bandwidth flow conservation discipline** — Refine Spec 04 architecture for Starlink ↔ ODC internal bandwidth. Worked at module level but never battle-tested at scale. Watch for double-counting between bandwidth revenue (Starlink) and bandwidth cost (ODC).
- **Vehicle build cost as forward-demand-sized non-module claim** — Spec 09 architecture. Theoretically correct. May surface edge cases when the queue gate competes with module CapEx for limited cash.
- **AI Stack on-top-of-ODC vs standalone** — resolved 2026-05-19 as standalone. Principle pending: "modules with at-cost internal supply still get their own IRR engine."

These get added with concrete incidents as the rebuild surfaces them.

---

## How to use this doc

**Architecture spec**: Open with a reference to this doc. Every architectural decision in the spec is justified against one or more of these principles. If a decision violates a principle, the spec author either revises the decision or adds a one-paragraph justification for the exception (and the exception goes into a "Known Drift" section that future audits scan).

**Module / sprint specs**: Open with the Rule Compliance Preamble (Model Execution Rules) and a one-line reference to this doc. Sprint changes are checked against the principles before writing.

**Plugin execution chats**: Refuse to execute a spec that doesn't open with the Rule Compliance Preamble. If a write violates Principles 15–17 (one concept per write, copyToRange contract, delete superseded rows), halt and push back to spec author.

**Verification chats / audits**: Run through Principles 19–23 (sanity halt, edge-year reads, stale-ref scan, round-trip stability, calibration targets) as the standing audit checklist.

---

## Amendment log

- **2026-05-19 (initial draft)** — 23 principles in 6 sections. To be updated as rebuild surfaces additional load-bearing failure modes.
- **2026-05-22 (distilled version)** — This file. Verbatim source preserved in `reference/01_Lessons_Learned_FULL.md`.
