# Calibration and Verification

**Purpose**: Codifies the calibration target discipline and the universal verification protocol that runs at the end of every sprint.

**Why this matters**: The first build had no anchored outputs and no quantitative halt thresholds. Calibration drift was discovered at audit, not at sprint completion. The rebuild puts both at the centre of every sprint, which is why we now ship sprints with PASS confidence instead of "looks plausible, will audit later."

---

## 1. Calibration anchors — what they are

A calibration anchor is a *disclosed actual value from a credible recent source* that the model must reproduce within tolerance. For the SpaceX rebuild v2, anchors come from:

- The Q4'25 CLEANUP model (Vlad's curation of recent disclosed financials)
- The SpaceX S-1 (filed 2026-05-20; superseded some Q4'25 anchors with audited 2024 figures)
- The Earth tab J column (2025 column) and Mars & Moon F column (2025 column) of the Q4'25 model

For a new model build, anchors come from the most credible recent-actuals source: latest 10-K, S-1 filing, last funding round disclosure, or a curated estimates file from the model owner. The anchors are locked in the architecture spec; the model is calibrated to them before it is asked to project from them.

## 2. The SpaceX rebuild v2 anchor table (2025)

| Metric | Target | Tolerance | Source |
|---|---|---|---|
| Group Revenue | $14.65B | ±5% | Q4'25 + S-1 |
| Group EBITDA | $8.69B | ±5% | Q4'25 + S-1 |
| Group FCF | $3.67B | ±5% | Q4'25 + S-1 |
| F9 launches | 171 | ±5% | Q4'25 |
| Starlink+DTC revenue | $7.85B | ±5% | Q4'25 |
| Constellation D&A | $707M | ±10% | Q4'25 |
| Total OpEx (post-Sprint 8.5) | $4.48B | ±5% | Rebuild architecture (revised from raw $3.82B) |
| Total Module CapEx | $1.24B | ±5% | Rebuild architecture (vehicle build at Allocator, revised from $2.03B) |
| Total Group CapEx (post-Sprint 10) | $7.03B | ±5% | Q4'25 |
| Starshield revenue | $2.52B | ±5% | Q4'25 |
| Active V2 BB sat count | 5,246 | exact | Q4'25 |
| Active V2 DTC sat count | 650 | exact | Q4'25 |
| BB subs | 6.41M | within 5.5–7.5M range | Q4'25 |

For new models, build the equivalent table from the company's latest disclosed financials.

---

## 3. Tolerance philosophy

- **±5% for major P&L / FCF items** — Revenue, EBITDA, FCF. This is the standard tight tolerance.
- **±10% for D&A and other items with significant model architecture choices** — D&A depends on capitalization rules, useful life assumptions, asset categorization. ±10% allows the model to use disclosed totals without micromatching the accounting taxonomy.
- **Exact for fleet counts, launch counts, sub counts** — these are physical or contractual quantities that should match disclosure precisely.
- **Within a range for items with disclosure-band uncertainty** — e.g., BB subs reported as "5.5–7.5M range" rather than a precise figure.

If a target is breached, the response depends on whether the breach is *fixable* (in spec, by a formula correction) or *architectural* (the target itself was derived under an assumption the rebuild has since revised). Sprint 8's breakdown is the canonical example — see `08_Worked_Examples.md`.

---

## 4. Halt thresholds — when to stop

A halt threshold is a quantitative trigger that says "if this value falls outside this range, STOP execution." Every sanity check in every spec has a halt threshold. Examples:

- Implied DTC subs > 15M in 2025 → halt (disclosed Starlink total is ~5M; 15M is structurally impossible)
- Module Blended IRR < 0 in years where module is actively allocating cash → halt (negative-IRR modules should get zero allocation)
- Conservation row ≠ "OK" in any year → halt (model integrity broken)
- 5x round-trip recalc moves any value >$1M → halt (within-year cycle is bistable, redesign required)
- `#REF!` / `#VALUE!` / `#DIV/0!` anywhere → halt (formula or reference broken)

The plugin execution chat refuses to proceed past a halt threshold. The spec author either corrects the spec or amends the threshold (with justification).

---

## 5. The universal verification protocol

Every sprint runs this protocol at the end, before declaring done. Order matters: errors found early prevent wasted work on downstream checks.

### Step 1 — Workbook-wide error scan
`#REF!`, `#VALUE!`, `#DIV/0!` count must = 0.

### Step 2 — Conservation check block
Read Group P&L conservation row (D108:AC108 or equivalent) across all years. Every cell must = "OK". If any year shows anything else, halt and trace.

### Step 3 — Internal flow conservation
For every internal transfer flow (Starlink ↔ ODC bandwidth, Customer Launch ↔ all consumers, etc.), the conservation row verifies:
```
Σ Source internal transfer revenue (year N) = Σ Consuming module internal COGS (year N)
```
Must = 0 within $1mm tolerance at every year.

### Step 4 — Allocator OUT label-based references resolve
For every module's Allocator OUT block, attempt an INDEX/MATCH pull on each canonical label from a different tab. Confirm each pull resolves to the correct row. This catches row-shift drift that conservation can't.

### Step 5 — Vending-machine test
On every module tab: `Allocator OUT Module EBITDA = Gross Profit`. If they don't match, either R&D/SG&A/overhead leaked onto the module tab (Rule 13 violation) or the OUT block is pulling from the wrong row.

### Step 6 — Stale-reference scan (Rule 22)
For every cross-sheet reference on Valuation, Allocator, and Group P&L: verify the source cell's column-A label matches the consumer's labeled concept. This is the V26.1 audit-finding catcher.

### Step 7 — 5x round-trip recalc stability
Press F9 five times. Capture key cells (10–20 representative values) before and after. No value should move >$1M. Bistability under iterative calc is real and must be designed out.

### Step 8 — Calibration anchors hit within tolerance
Per the sprint's §6 (Calibration anchors + halt thresholds). Every relevant anchor checked. Out-of-tolerance = breach; categorize as fixable or architectural; address in same sprint or next patch sprint.

### Step 9 — Claude Log entry
Append a row to the Claude Log tab on the workbook:

| Date | Sprint | Tabs touched | Summary | Outstanding | Next sprint |
|---|---|---|---|---|---|
| YYYY-MM-DD | N | tab list | What landed, what changed, calibration results | Deferred items / open questions | Sprint N+1 name |

---

## 6. PASS / FAIL / PASS-with-overshoot

Three terminal states for a sprint:

### PASS
All halt thresholds clear. All calibration anchors hit within tolerance. Universal verification protocol clean across all 9 steps. Sprint is complete; next sprint can proceed.

Examples: Sprint 4 (14 of 15 anchors PASS, Constellation D&A flagged for Sprint 4.5 retune). Sprint 5 (all §6.4 + Sprint 4.5 patch anchors PASS). Sprint 7 (all §6.6 halt thresholds hit exact in 2025).

### FAIL
A halt threshold tripped. Spec is incorrect or incomplete. Plugin halts mid-sprint or at final verification. Spec author diagnoses, patches, re-runs.

### PASS-with-overshoot
All halt thresholds clear, but one or more calibration anchors breach tolerance for a documented architectural reason (the target itself reflects an assumption the rebuild has revised). The breach is decomposable into "fixable in patch" + "architectural divergence requires anchor update."

Example: Sprint 8 — Total OpEx +24.5% above $3.82B target. Decomposed into $226M fixable in Sprint 8.5 (CS overcount + G&A internal transfer overcount) + $711M architectural divergence (pre-revenue R&D floors per Architecture §12.1 amendment + base differences). Recommendation: update Roadmap §6.7 anchor target $3.82B → $4.48B reflecting current architecture.

PASS-with-overshoot is acceptable when the architectural divergence is explicitly justified and the anchor table is updated to reflect the new target. It is NOT acceptable when the divergence is unexplained or the update is deferred to "audit later."

---

## 7. Calibration retune workflow

When a calibration anchor breaches tolerance:

1. **Decompose the breach**: Is it formula-fixable (a calculation error or label mismatch) or architectural (the target itself is wrong relative to the rebuild's architecture)?
2. **If formula-fixable**: Write a patch sprint (Sprint N.5) with the specific fix. Patch sprints are small — typically <30 min plugin runtime.
3. **If architectural**: Update the anchor table in the architecture spec (and Sprint Roadmap §6.X). Document the change in the spec's §9 amendments. Re-verify against the new target.
4. **Never "audit later"**: Calibration drift compounds. A sprint with an unexplained breach blocks downstream sprints because their anchors are calibrated against the same architecture.

The Sprint 4 → Sprint 4.5 → Sprint 5 sequence is the canonical retune workflow:
- Sprint 4 PASS 14/15 anchors. Constellation D&A breach flagged.
- Sprint 4.5 patch designed within Sprint 5 prep. Added legacy V1/V1.5 D&A (~$130M) + facility D&A (~$140M) to close the gap.
- Sprint 5 absorbed Sprint 4.5 patch. PASS on every Sprint 4.5 patch anchor + Sprint 5 ODC §6.4 anchors.

---

## 8. Calibration vs MC ranges

The MC range columns on Assumptions and the calibration anchors serve different purposes:

- **Calibration anchors** are the year-zero ground truth. The Base Case value of every input should be tuned so the year-zero outputs hit anchors within ±5%. Calibration is a deterministic exercise.
- **MC ranges** capture honest forecasting uncertainty about the future. The Base Case is the point estimate; MC Min/Max bracket the plausible range; the distribution shape encodes prior belief about where the truth is most likely to fall.

A common confusion: trying to widen MC ranges to "explain" a calibration breach. This is backward. If calibration is breached, fix the Base Case (or the architecture). MC ranges are about uncertainty around the Base Case, not justification for it.

---

## 9. What to do when Vlad pushes back on an anchor

The anchor table is not immutable. Vlad may push back on a specific anchor if:

- The disclosure source has been superseded (e.g., S-1 filing replaces Q4'25 estimate)
- The architecture spec amendment has shifted what the anchor measures (e.g., vehicle build moved to Allocator, so Module CapEx target lowers)
- A new sprint has surfaced that the original anchor was derived under a different methodology assumption

In all three cases, the workflow is the same:
1. Update the anchor in the architecture spec's calibration table.
2. Add an entry to the architecture spec's Amendment Log with date + reason.
3. Update Sprint Roadmap §6.X if the anchor is referenced there.
4. Re-run the most recent sprint's calibration against the new anchor.

Never silently move an anchor. Always document the move and the reason.

---

## 10. The PASS rate — what we are seeing

For the SpaceX rebuild v2 through Sprint 8:
- 8 of 12 sprints landed PASS or PASS-with-overshoot
- 1 PASS-with-overshoot fully decomposed ($226M fixable in Sprint 8.5 + $711M architectural; anchor table updated)
- 0 silent breaches
- 0 conservation regressions
- 0 stale-reference bugs surfaced by Rule 22 scans

For comparison, the original build went 35 specs without ever achieving a sprint-level PASS confidence — every "complete" spec accumulated quiet drift that V26.1 audit eventually surfaced as five material bugs.

The difference is the discipline of this protocol. When the protocol runs at end of every sprint, drift cannot accumulate.

---

## Related

- `04_Model_Execution_Rules.md` — the rules whose verification this protocol enforces
- `06_Sprint_Spec_Template.md` — drop-in template with calibration sections wired in
- `08_Worked_Examples.md` — Sprints 4/5/7/8 case studies showing PASS / PASS-with-overshoot / retune patterns
- `reference/03_Sprint_Roadmap_and_Verification_FULL.md` — the full universal verification protocol with sprint-specific acceptance criteria
