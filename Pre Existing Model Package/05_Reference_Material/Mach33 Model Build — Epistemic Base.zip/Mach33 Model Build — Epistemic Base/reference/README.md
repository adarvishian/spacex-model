# Reference — Full constitutional docs from the SpaceX rebuild v2

These are the verbatim source documents from the SpaceX Model Rebuild v2 project, copied here as templates for any future Mach33 model build (Portal, ASTS, next SpaceX iteration, etc.).

**Status**: Authoritative, locked. The numbered docs in the parent folder (`01_*` through `09_*`) distill these for the epistemic-base presentation; for the *exact* text the rebuild ran against, read these.

## Files

| File | Purpose | Size |
|---|---|---|
| `00_README_Sprint_Kickoff.md` | Navigation + protocol + kickoff prompt template | 13KB |
| `01_Lessons_Learned_FULL.md` | The 23 principles with verbatim V30.5 incident citations | 27KB |
| `02_Architecture_and_Methodology_FULL.md` | Full structural design + math conventions (the source of truth) | 58KB |
| `03_Sprint_Roadmap_and_Verification_FULL.md` | 12-sprint plan + per-sprint acceptance criteria + universal verification protocol | 43KB |
| `Model_Execution_Rules_FULL.md` | The 23 plugin-side rules + Rule Compliance Preamble template | 27KB |

## How to use these for a new model build

The structural skeleton of each doc is reusable. For most new builds, the workflow is:

1. **Copy each file** to your new model's project folder. Rename:
   - `00_README_Sprint_Kickoff.md` → keep filename (it's the navigation index)
   - `01_Lessons_Learned_FULL.md` → `01_Lessons_Learned.md` (drop the `_FULL` suffix)
   - `02_Architecture_and_Methodology_FULL.md` → `02_Architecture_and_Methodology.md`
   - `03_Sprint_Roadmap_and_Verification_FULL.md` → `03_Sprint_Roadmap_and_Verification.md`
   - `Model_Execution_Rules_FULL.md` → `Model Execution Rules.md`

2. **Adapt content per doc**:
   - `00_README` — change project name and folder paths
   - `01_Lessons_Learned` — most principles are model-agnostic; prune any SpaceX-specific principles, add new ones as needed for the new model
   - `02_Architecture_and_Methodology` — biggest adaptation. Update the tab list, IRR engine specifications, calibration anchors, internal transfer flows, etc. for the new model
   - `03_Sprint_Roadmap_and_Verification` — adjust sprint sequence to the new model's tab count. The universal verification protocol (the part at the end) is reusable verbatim
   - `Model Execution Rules` — reusable verbatim. The 23 rules are about how to direct AI to build a complex Excel model, not about SpaceX specifically

3. **Add the calibration anchor table** to the architecture spec from the new model's most-credible recent-actuals source (10-K, S-1, latest funding round, curated estimates).

4. **Run the bootstrap protocol** per `../02_Bootstrap_Protocol.md`.

## Why "_FULL" suffix on three of these

The parent folder has distilled versions named `03_The_23_Lessons_Learned.md`, `04_Model_Execution_Rules.md`, etc. To prevent confusion between the distilled headline docs and the verbatim source docs, the source docs here carry the `_FULL` suffix. The architecture doc and sprint roadmap don't have distilled versions (the architecture cheat sheet in `../05_Architecture_Patterns.md` is a different shape — patterns rather than the full spec), so the `_FULL` suffix on those just signals "this is the constitutional doc, not a derivative."

When copying to a new model, drop the `_FULL` suffix — the new model only has one version of each.

## Cross-references inside these docs

The constitutional docs reference each other and the workspace folder by file path (e.g., `/Users/vladsaigau/Documents/Claude/Projects/Starlink Module/...`). When you copy them to a new model:

1. Search-and-replace the path prefix (`/Users/vladsaigau/Documents/Claude/Projects/Starlink Module/` → `/Users/[name]/Documents/Claude/Projects/[New Model]/`).
2. Update the kickoff prompt template in `00_README_Sprint_Kickoff.md` with the new paths.
3. Update memory pointers in the project's memory folder.

## Provenance

- All five docs were drafted between 2026-05-19 and 2026-05-22 during the SpaceX rebuild v2 bootstrap and early sprints.
- Last updated dates are at the top of each doc.
- Amendment logs at the bottom of each doc track every change since initial draft.

## Related

- `../skills/mach33-model-build-SKILL.md` — packaged skill that embeds the content of these docs for any new model chat
- `../01_The_Epistemic_Base.md` — the meta-lessons learned from running against these docs
- `../02_Bootstrap_Protocol.md` — how to use these docs to start a new model
- `../06_Sprint_Spec_Template.md` — drop-in template that operationalizes the Rule Compliance Preamble from `Model_Execution_Rules_FULL.md`
