# Model Execution Rules — The 23

**Status**: Mandatory for every sprint spec.
**Authored**: 2026-05-18, expanded 2026-05-19, amended 2026-05-22.
**Verbatim source**: `reference/Model_Execution_Rules_FULL.md`.

These rules codify the execution discipline required to make changes to a Mach33 modular valuation model without breaking adjacent cells, conservation, or downstream references. They are the operational counterpart to `03_The_23_Lessons_Learned.md` — the lessons explain *why*, the rules dictate *what to do*.

A spec author must structure changes so the rules are followable. Plugin execution chats refuse to write a single cell if the spec doesn't open with the Rule Compliance Preamble (Section IX of this doc) with all boxes ticked or justified as N/A.

---

## A. Atomic-write discipline

### Rule 1 — One concept per write

Never mix concepts in a single tool call. Separate writes for:

- Label changes (column A text, header rows). One tool call.
- Formula writes (a single row's year-row formulas, or a single column's stack of independent formulas). One tool call.
- Number-format / font / fill changes. One tool call.
- Reference rewires (changing one cell's source pointer). One tool call.

The Spec 03 disaster — a single `copyToRange` whose `cells` dict mixed labels with formulas, tiling labels across column D and overwriting formulas — was caused by violating this rule. Splitting the operation into three writes would have prevented the cascade.

### Rule 2 — `copyToRange` contract

The source of a `copyToRange` must be a single cell or a single contiguous row. Never a non-contiguous dict.

Valid: source `E14`, destination `F14:AC14` (tiles formula across row). Source `D14:D14`, destination `D14:D17` (tiles down column).

Invalid: source dict `{"D14": ..., "D16": ..., "D18": ...}` — undefined behavior, observed to corrupt cells outside the intended pattern.

### Rule 3 — Bounded-CAGR row construction pattern

Every row that uses the start-bound CAGR mechanic gets the same three-step construction:

1. **Step 1 — Write column D anchor explicitly.** `D{row} = =Assumptions!$B${start_input}`. One tool call. Just D.
2. **Step 2 — Write column E with the bounded-CAGR formula referencing D.** One tool call. Just E.
3. **Step 3 — Copy E across F:AC.** `copyToRange source=E{row}, destination=F{row}:AC{row}`.

Do these one row at a time. Confirm before starting the next row. Do not stack four rows' worth of CAGR construction into one tool call sequence.

In modern practice this is largely superseded by Rule 23 (anchor-and-offset) for deterministic ramps. Use Rule 23 by default; use Rule 3 only when bounded-CAGR semantics require the MIN/MAX guard.

### Rule 6 — Inline Excel formulas in spec, not convention references

Every cell write in a spec is specified with the full Excel formula in inline notation. Not "use the bounded-CAGR pattern from Rule 3" — the actual formula text.

This is for the plugin execution chat, which has no memory of past specs and no filesystem access to read conventions. If the spec doesn't contain the literal formula, the plugin halts at pre-flight.

---

## B. Verification gates

### Rule 4 — Mandatory verification gate after each section

After writing a discrete section of changes:

1. **Read back the cells just written** in at least four columns: D (2025), I (2030), S (2040), AC (2050). Confirm values match spec expectations.
2. **Read `Group P&L D108:AC108`** (or your model's conservation row). Every cell must = "OK". If any cell shows anything else, **stop and trace** before proceeding to the next section.
3. **Document the landing values in spec terms** (e.g. "Launch R&D 2030 = 8.2%, AC year = 4.0% at floor — matches spec target").

This is the single most important rule. Most bugs in V26 would have been caught by a verification gate at the end of the OpEx section, before moving to Starlink COGS.

### Rule 5 — Conservation gate is non-negotiable

The Group P&L conservation check block is the model's integrity proof. After any change:

- **Before declaring a section done**: read the conservation row across all years. Any year ≠ "OK" → stop, trace, fix before continuing.
- **Before declaring a full spec done**: read the full conservation block across all years. Document any non-zero residual (target = exact zero within $1mm tolerance).
- **Conservation breakage is the highest-priority fault.** A spec is not done if conservation is broken. Push back to the user with the failing check identified.

Never accumulate unresolved breakage. Never "fix it later" — the next spec's diff makes it impossible to isolate which change broke what.

### Rule 16 — Edge-year verification, not just middle years

When reading back values per Rule 4, **always include 2025, 2030, 2040, and 2050** in the verification set. Don't just spot-check the year 2030 column.

Failure modes that only surface at edges:
- 2025 — pre-Starship-commercial; many modules at zero; division-by-zero risk
- 2040 — terminal-flow tapering; some lines flip sign as ARPU drift compounds
- 2050 — known out-year breakdown; useful to confirm bug is unchanged

If a spec only reads 2030, edge bugs survive into the next refine.

---

## C. Order and recovery

### Rule 7 — Deterministic execution order

Within a spec, execution proceeds in a fixed order. Never jump back to an earlier stage without re-running downstream verification.

Standard order:
1. Assumptions tab additions. All new inputs first, with stub values.
2. Module tab changes — one module at a time.
3. Cross-cutting tab changes (CapEx, OpEx).
4. Group P&L rewires.
5. Conservation checks.
6. Diagnostics + Valuation (only after conservation passes).

If a later step uncovers that an earlier stage was wrong, stop the in-progress step, return to the earlier stage, fix it, and re-run verification of every stage from that point forward. Do not push through.

### Rule 8 — Pre-existing out-year breakage is its own scope

Models may have known pre-existing out-year breakage. Spec patches are not required to fix pre-existing out-year issues unless the spec explicitly targets them.

But specs must document whether their changes interact with out-year breakage. If a verification step shows out-year numbers that look wrong, document them and confirm they were already wrong in the prior workbook version. Don't blame the current spec.

### Rule 9 — When in doubt, ask

If execution encounters a cell that doesn't match what the spec describes, a conservation break that the spec didn't anticipate, or a formula that requires interpretation — **stop and ask**. Don't guess. Don't fix-and-hope. The cost of a back-and-forth is far smaller than the cost of a silent corruption that takes three specs to surface.

---

## D. Reference safety

### Rule 10 — Row insertions are forbidden in cross-referenced tabs

Never insert rows in any tab that's referenced by another tab. Append new content below existing rows instead.

Cross-sheet absolute references break silently when rows shift. The bug shows up two refines later as a conservation miss and tracing it is brutal. Default answer: don't insert.

### Rule 11 — Updating a section means updating its SUM ranges and its conservation check

When adding a new line item inside an existing section, the spec must enumerate and the execution must update:

1. The section's Total row (SUM range expansion)
2. Any "by module" aggregator on Group P&L
3. The corresponding conservation check on Group P&L
4. Diagnostic memo rows that derive from the section
5. The Valuation tab (or equivalent downstream consumer)

A new line item lands clean only if all five touch points are updated. Spec authors must enumerate the touch points; execution must hit each one and verify.

### Rule 12 — Allocator OUT references are by label, not row number

References within the Allocator tab that point at module Allocator OUT rows use **label-based** lookups (INDEX/MATCH on the row label), not absolute row numbers.

When a spec changes a module's Allocator OUT block, the Allocator tab continues to find the right row via the label. Execution must verify that after a change, the Allocator tab still pulls the correct values.

Don't rewrite the label-lookup pattern with absolute row references — that defeats the rule and makes every future Allocator OUT change a row-shift hunt.

---

## E. Architectural guardrails

### Rule 13 — Vending-machine framing is a structural test

Every module's P&L stops at Gross Profit = Module EBITDA. **No module tab may contain:**
- R&D (any flavour). Lives on OpEx tab.
- SG&A. Lives on OpEx tab.
- Customer service / billing. Lives on OpEx tab.
- Corporate overhead / allocations. Retired entirely.
- Taxes. Group P&L only.

A spec that puts any of these on a module tab violates vending-machine framing and must be rejected. Spec authors check this before submission; execution checks this before write.

The single exception is the Launch module's internal transfer revenue and at-cost transfer logic — that's not OpEx, it's a COGS-eliminating intercompany flow.

### Rule 14 — No hardcoded constants in formula cells

If a number appears in a formula on any tab other than Assumptions, it must instead be a reference to an Assumptions cell.

Future refines (especially Monte Carlo) cannot find hardcoded constants without grep. MC ranges only attach to Assumptions cells. The "anything arbitrary is MC" rule requires that arbitrary numbers live in Assumptions where they can be MC-flagged.

Exception: True mathematical constants (π, conversion factors like 1e6) are allowed inline. Anything that's a behaviour assumption (rate, threshold, share, multiplier) is not.

---

## F. Calibration discipline

### Rule 15 — Sanity check failures halt execution

When a spec includes a sanity check and the check fails:
- Execution does not proceed. Stop. Document the failure.
- Push back to the user with the specific check that failed and the actual vs expected value.
- Do not "proceed and document" — that's how 22M DTC subs in 2025 survived V26 execution unchallenged.

Spec authors: when writing sanity checks, specify what "fails" means quantitatively (e.g., "if implied DTC subs > 15M in 2025, halt; the disclosed Starlink figure is ~5M total"). Don't leave the threshold to interpretation.

---

## G. Conventions and robustness

### Rule 17 — Memo rows are clearly flagged

Rows that exist as diagnostics, not as operative line items in any sum, must:
- Start with **"Memo:"** in column A (e.g. `Memo: Implied blended ARPU`).
- Be **excluded from any SUM range** in the section.
- Use **italic font** in the format.

Without the convention, a future refine sweeps a memo into a total and double-counts.

### Rule 18 — Format inheritance for new rows

When adding new rows in an existing section, copy formatting from the most similar existing row in that section. Don't leave new rows in "General" format. Visual inconsistency is the first sign that a row was added without thinking about the section.

### Rule 19 — Source workbook preservation (modified — Vlad handles saving)

Vlad pre-names the workbook via Save-As before sending the kickoff prompt. Vlad saves during/after execution. Specs do not include "save the workbook" steps. Plugin operates on the live open workbook session.

(Original Rule 19 was about plugin save-as. Amended 2026-05-20 per standing process rule: plugin does NOT issue save / save-as commands.)

### Rule 20 — Pre-revenue modules need IFERROR guards on ratios

For any module that's pre-revenue in a given year (Lunar Mars throughout; ODC pre-2030; AI Stack pre-Sprint-10), margin and ratio formulas must be guarded:

```
WRONG: =R98 / R92                            (Gross Margin % when R92 = 0)
RIGHT: =IFERROR(R98 / R92, 0)
```

Same applies to EBITDA Margin %, ROIC/IRR derivatives, per-unit revenue ratios, any division by a module revenue or sub count. Without IFERROR, the cell shows `#DIV/0!` which cascades into Group-level diagnostics and conservation checks.

### Rule 21 — Internal flows need elimination + conservation

Whenever a spec adds a new internal flow between two modules:
1. Source module books the flow as Internal Transfer Revenue.
2. Consuming module books the same dollar value as Internal COGS.
3. Group P&L Inter-Module Eliminations block subtracts the flow once.
4. A conservation check row verifies: `Internal Transfer Revenue (source) = Sum of Internal COGS (consumers)` at every year.

Forgetting any of the four breaks Group Revenue. The conservation check is the safety net; the spec author enumerates it explicitly.

### Rule 22 — Stale-reference scan every spec

After every spec lands, before declaring done, execution must scan the Valuation and Allocator tabs for cross-sheet references that may have drifted as the spec's changes propagated. Specifically:

1. Read every cell on **Valuation** that contains a `'Sheet'!Cell` reference. For each, verify the source cell still holds the concept the Valuation label claims (e.g. if it says "Blended IRR" the source cell better be a Blended IRR, not a Forward IRR).
2. Same for **Allocator** tab — every per-module input row's source verified.

If any label/source mismatch is found, halt and report. This is how three material bugs survived in V26.1 (Dashboard "True EBITDA" labels, "Blended IRR" pointing at Forward IRR, Valuation DCF source pulling pre-tax instead of Group FCF).

### Rule 23 — Anchor-and-offset formula pattern (no neighbour-chasing for ramps)

For any year-row formula computing a deterministic ramp (start%, end%, CAGR; step function; any "year N from start" derivation), use the **anchor-and-offset** pattern. Forbidden: the recursive "this year = prior year × growth" form.

**Required structure**:
1. Each tab has a **Year Offset** helper row near its year header. D = 0, E = 1, F = 2, ..., AC = 25.
2. Year-row formulas reference an absolute **anchor cell** (`$D$14`) and the offset cell on the same column (`E$5`).
3. Every cell in the row has the same form. No prior-column references.

**Example**:
```
D14  = =Assumptions!$B${start_input}                                                 (anchor at start year)
E14  = =IF(Assumptions!$B${cagr}>=0,
            MIN(Assumptions!$B${end}, $D$14*(1+Assumptions!$B${cagr})^E$5),
            MAX(Assumptions!$B${end}, $D$14*(1+Assumptions!$B${cagr})^E$5))
F14:AC14 = copy E14 across (E$5 shifts to F$5, G$5, ... correctly)
```

Every cell in the row references **only** `$D$14` (locked anchor) and `E$5` (year offset). No `D14`, `E14` cross-column chasing.

**Why this rule**: Row moves don't break formulas. Row insertions don't cascade. Row deletions don't break the propagation.

**When the recursive form is unavoidable**: Genuinely year-chained logic — `EoY subs = BoY subs + Net adds`, `Cumulative CapEx = prior cumulative + this-year CapEx`. These have to chain. Mark them explicitly with a comment in the spec ("Year-chained — Rule 23 exception, intentional").

---

## H. Drift prevention (added 2026-05-18 after V26.1 audit)

Rules 22 and 23 above. Both added after the V26.1 deep audit surfaced five material bugs that conservation didn't catch (IRR engines blow up in out-years, Valuation DCF pulls pre-tax module FCF, Valuation D&A/EBIT/CapEx refs broken or pointing at non-existent rows, ODC tab still computes "MOVED" concepts, Dashboard "Blended IRR" actually pulls Forward IRR).

---

## IX. The Rule Compliance Preamble (MANDATORY at top of every spec)

Copy-paste verbatim at the top of every sprint spec. Tick each box. If a rule doesn't apply, tick it with "N/A" and a one-line justification.

Plugin execution chats refuse to start work if any box is unchecked without justification.

```markdown
## Rule Compliance Preamble (mandatory)

This spec follows `Model Execution Rules.md` and the four constitutional docs. Confirm each before execution:

- [ ] **Rule 1** (one concept per write) — section structure separates labels, formulas, formats.
- [ ] **Rule 3 / 23** (formula pattern) — bounded-CAGR / ramp formulas use anchor-and-offset. Year-chained formulas explicitly flagged as Rule 23 exceptions with one-line justification.
- [ ] **Rule 4** (verification gate) — every section has explicit read-back cells (D, I, S, AC) + expected values.
- [ ] **Rule 6** (inline formulas) — every cell write specified with the full Excel formula, not a convention reference.
- [ ] **Rule 10** (no row insertions) — confirm no `insert_row` operations; all new content appended below existing data.
- [ ] **Rule 11** (touch points) — every new line item lists its SUM range / aggregator / conservation check / Valuation pulls.
- [ ] **Rule 12** (label-based cross-tab refs) — any Allocator / Valuation / Group P&L pulls use INDEX/MATCH on label.
- [ ] **Rule 13** (vending-machine test) — no module tab gets R&D / SG&A / overhead / taxes added.
- [ ] **Rule 14** (no hardcoded constants) — every behaviour input lives on Assumptions.
- [ ] **Rule 15** (sanity check halt thresholds) — every sanity check has a quantitative halt condition.
- [ ] **Rule 19** (save-as) — Vlad handles all saving; spec contains no save instructions.
- [ ] **Rule 22** (stale-ref scan) — Valuation + Allocator + Group P&L scan listed in §Verification.

Architecture & Methodology compliance:

- [ ] Module P&L follows vending-machine framing (Architecture §3).
- [ ] Per-sat / per-launch marginal IRR engine (Architecture §5), not fleet-level MFW-IRR.
- [ ] Allocator OUT contract uses canonical labels (Architecture §4.2).
- [ ] Year-offset helper row at row 5 + year header at row 4 on every tab with year columns.
- [ ] ZERO `OFFSET()` formulas; INDEX:INDEX patterns used for dynamic ranges (Principle 11).

If any box is unchecked, the spec author justifies or amends before execution starts.
```

---

## Quick-reference checklist for execution chats

**Before starting**:
- Read this doc.
- Spec has the Rule Compliance Preamble at the top with all boxes ticked (or justified N/A).
- Confirm target workbook name (Rule 19 — Vlad sets via Save-As before kickoff).
- Confirm spec lists touch points for every new line item (Rule 11) and halt conditions for sanity checks (Rule 15).

**During each section**:
- One concept per write (Rule 1).
- `copyToRange` source is single cell or single row only (Rule 2).
- Ramp formulas use anchor-and-offset pattern (Rule 23) — no prior-column chasing.
- No row insertions in cross-ref tabs (Rule 10).
- No hardcoded constants (Rule 14).

**After each section**:
- Read back D, I, S, AC for the cells just written (Rule 4 + Rule 16).
- Read conservation row — all "OK" (Rule 5).
- If sanity check fails, halt (Rule 15).
- Pre-revenue modules: confirm IFERROR guards on ratios (Rule 20).

**Before declaring done**:
- Workbook-wide `#REF!` / `#VALUE!` / `#DIV/0!` scan (zero results).
- All conservation checks across all years = OK.
- Internal flow conservation (if any) passes (Rule 21).
- Allocator OUT label-based references still resolve (Rule 12).
- Module Allocator OUT EBITDA = Gross Profit per vending-machine test (Rule 13).
- **Stale-reference scan**: Valuation + Allocator cross-sheet refs verified against labels (Rule 22).
- Claude Log entry written to the Claude Log tab.

---

## Amendment log

- **2026-05-18 (initial)** — Rules 1–9 drafted after Spec 03 execution produced material bugs. All rules trace to specific failure modes observed in V26.
- **2026-05-18 (expansion)** — Added Rules 10–21 covering reference safety, architectural guardrails, calibration discipline, and conventions/robustness. Grouped rules under section headers A–G.
- **2026-05-18 (V26.1 audit aftermath)** — Added Rules 22–23 after deep audit surfaced five material bugs that conservation didn't catch. Added mandatory Rule Compliance Preamble.
- **2026-05-20 (Standing process rules)** — Rule 19 amended: plugin does NOT issue save / save-as commands. Vlad handles all saving.
- **2026-05-22 (distilled version)** — This file. Verbatim source preserved in `reference/Model_Execution_Rules_FULL.md`.
