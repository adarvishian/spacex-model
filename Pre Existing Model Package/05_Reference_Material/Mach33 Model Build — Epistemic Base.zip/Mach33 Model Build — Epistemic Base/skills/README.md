# `mach33-model-build` skill

The `mach33-model-build` skill embeds the rebuild-v2 approach for any modular Mach33 financial model build (SpaceX, Portal, ASTS, future rebuilds). It is self-contained — when triggered, it loads the constitutional framework (23 lessons, 23 execution rules, architectural patterns) directly into the active chat without requiring external doc reads.

## What's in here

- **`mach33-model-build-SKILL.md`** — the skill source file (37KB). This is what gets installed.

## When the skill triggers

The skill triggers automatically when Vlad or a Mach33 team member uses any of these phrases:

- "rebuild the model" / "rebuild from scratch"
- "scope this sprint" / "sprint kickoff" / "draft the architecture spec"
- "write a sprint spec" / "execute Sprint N" / "plugin execution"
- "Rule Compliance Preamble" / "constitutional docs"
- "vending-machine framing"
- "anchor-and-offset" / "INDEX/MATCH by label" / "no OFFSET"
- "allocator OUT contract" / "queue gate" / "per-sat IRR"
- "calibration target" / "stale-ref scan"

Plus general model-build framings like "we're starting a new modular model" or "let's restructure the [Portal/ASTS/X] model."

## When the skill does NOT trigger

- One-off Excel cleanup (use `xlsx` skill instead)
- Mach33 weekly analyses (use `mach33-weekly-analysis`)
- Thesis framing (use `mach33-thesis-library`)
- Chart aesthetics (use `mach33-chart-style`)
- Audit / fact-check (use `mach33-audit`)

## How to install

### Option 1 — Save Skill button (Cowork)

1. Open this folder in Cowork mode.
2. Click the file `mach33-model-build-SKILL.md`.
3. Click "Save Skill" in the file view.
4. The skill appears in your `<available_skills>` list with the name `mach33-model-build`.

### Option 2 — Manual install (Claude Code / CLI)

The skill lives at `mach33-model-build-SKILL.md`. To install manually:

1. Copy the file to your local Claude skills directory (typically `~/.claude/skills/` or your plugin's skills directory).
2. Verify it appears in `<available_skills>` on next session start.

### Option 3 — Repackage as `.skill` zip

If you need to bundle the skill for distribution:

```
cd "/path/to/skills/"
mkdir mach33-model-build
cp mach33-model-build-SKILL.md mach33-model-build/SKILL.md
zip -r mach33-model-build.skill mach33-model-build/
```

The resulting `.skill` file can be installed via Cowork's "Save Skill" button by any colleague.

## What the skill contains

The skill is fully self-contained — no external file reads required. It embeds:

- **The bootstrap protocol** — when to rebuild from scratch vs refine; the five constitutional docs that must exist before sprints start
- **The 23 Lessons Learned** (verbatim from `01_Lessons_Learned.md`)
- **The 23 Model Execution Rules** (verbatim from `Model Execution Rules.md`)
- **The Standing process rules** (specs self-contained; Vlad handles saving; don't over-specify)
- **The Rule Compliance Preamble template** (16-box checklist)
- **Architectural patterns**: vending-machine framing, Allocator OUT canonical labels, queue gate formula, per-sat marginal IRR, anchor-and-offset, strategic carve-out, internal transfer mechanics, vehicle build cost, year horizon, MC discipline, scenarios after MC
- **The kickoff prompt template**
- **Plugin execution checklist + spec authoring checklist**
- **Claude Log entry format**
- **Amendment protocol for constitutional docs**

## How to use the skill in a sprint chat

1. **Spec author chat**: Use the kickoff prompt template (in the skill itself). Tell Claude you are about to scope/draft Sprint N for [model name]. The skill loads constitutional framework automatically.
2. **Plugin execution chat**: Same kickoff template. Hand Claude the spec to execute. The skill enforces the Rule Compliance Preamble before any cells get written.

The skill pairs well with other Mach33 skills:
- `mach33-audit` — for fact-checking model outputs after a sprint lands
- `mach33-chart-style` — for visualisations of model output
- `portal-context` — for Portal-specific scoping

It does NOT replace any of those — it complements them.

## When to amend the skill

- A new architectural decision becomes load-bearing across models (not just SpaceX) → update Section VI (architectural patterns) of `mach33-model-build-SKILL.md`
- A new failure mode warrants a new Principle in Lessons Learned → update both Section II (the lessons list) AND the source `01_Lessons_Learned.md` in the model's project folder
- A new operational rule emerges → update both Section V (the rules list) AND the source `Model Execution Rules.md` in the model's project folder

Amendments to the skill should be made by editing the source `mach33-model-build-SKILL.md` and then re-installing. Don't edit the installed copy directly.

## Related

- `../01_The_Epistemic_Base.md` — the meta-lessons the skill embeds
- `../02_Bootstrap_Protocol.md` — what the skill helps you do day one
- `../04_Model_Execution_Rules.md` — the rules the skill enforces
- `../05_Architecture_Patterns.md` — the architectural patterns the skill encodes
- `../reference/` — the full constitutional docs the skill is based on
