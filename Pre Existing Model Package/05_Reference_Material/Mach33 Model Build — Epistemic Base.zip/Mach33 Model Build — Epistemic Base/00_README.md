# Mach33 Model Build — Epistemic Base

**Purpose**: Knowledge transfer pack for any Mach33 colleague about to build, rebuild, or substantially refactor a modular valuation model with AI assistance.

**Source**: Distilled from the SpaceX Model V30.5 → Rebuild v2 transition (May 2026). The first build took 35 specs across 11+ days and produced a workbook nobody trusted. The rebuild — running for ~5 days at the time of writing — has produced PASS calibrations on 8 of 12 sprints with every meta-failure mode of the first iteration designed out of the workflow before any cell was written. This folder captures what changed.

**Author**: Vlad Saigau (Mach33) + Claude.

**Status**: Living document. Amend when a new load-bearing lesson surfaces.

---

## Reading order

Start with `01_The_Epistemic_Base.md` — the headline doc explaining what we now know about directing AI to build complex Excel models. Everything else supports it.

| Order | File | What it gives you | Read time |
|---|---|---|---|
| 1 | `01_The_Epistemic_Base.md` | The 8 meta-lessons that explain why this rebuild is working | 25 min |
| 2 | `02_Bootstrap_Protocol.md` | What to do day one when starting a new model | 15 min |
| 3 | `03_The_23_Lessons_Learned.md` | The 23 principles (the WHY), each tied to a V30.5 incident | 20 min |
| 4 | `04_Model_Execution_Rules.md` | The 23 operational rules + the Rule Compliance Preamble template | 15 min |
| 5 | `05_Architecture_Patterns.md` | The architectural primitives (vending machine, allocator, per-sat IRR, anchor-and-offset) | 15 min |
| 6 | `06_Sprint_Spec_Template.md` | Drop-in template for a new sprint spec | 5 min reference |
| 7 | `07_Calibration_and_Verification.md` | Calibration targets, halt thresholds, universal verification protocol | 15 min |
| 8 | `08_Worked_Examples.md` | Sprints 4/5/7/8 case studies — what was specced, what passed, what broke | 20 min |
| 9 | `09_When_To_Rebuild_vs_Refine.md` | The decision rule with the V30.5 case study | 10 min |

**Plus**:
- `skills/` — the `mach33-model-build` skill, packaged for installation and reuse on the next model
- `reference/` — the full constitutional docs from the SpaceX rebuild, verbatim, as templates for the next model

---

## Quickstart by use case

### "I'm about to start a new model from scratch (Portal, ASTS, anything)"

1. Read `01_The_Epistemic_Base.md` end-to-end.
2. Read `02_Bootstrap_Protocol.md`.
3. Install the `mach33-model-build` skill (`skills/README.md`).
4. Copy `reference/` files to your new model's project folder per `reference/README.md`.
5. Run the bootstrap protocol — five constitutional docs before Sprint 1.

### "I'm taking over an existing model and need to know how it works"

1. Read `01_The_Epistemic_Base.md`.
2. Read `05_Architecture_Patterns.md` for the conceptual primitives.
3. Read `03_The_23_Lessons_Learned.md` to understand why the model is structured the way it is.
4. Read the existing model's constitutional docs (typically `00_README_Sprint_Kickoff.md`, `01_Lessons_Learned.md`, `02_Architecture_and_Methodology.md`, `03_Sprint_Roadmap_and_Verification.md`, `Model Execution Rules.md` in the project folder).
5. Read the Claude Log tab on the workbook itself — every sprint's outcome is logged there.

### "I'm about to scope or execute a sprint on the existing SpaceX rebuild"

1. Read `04_Model_Execution_Rules.md` — particularly the Rule Compliance Preamble.
2. Read `06_Sprint_Spec_Template.md`.
3. Read `07_Calibration_and_Verification.md` — particularly the universal verification protocol.
4. Read the existing model's `00_README_Sprint_Kickoff.md` for the kickoff prompt template.
5. Use the kickoff prompt template verbatim at the start of the sprint chat.

### "I'm wondering whether to rebuild an existing model or just refine it"

1. Read `09_When_To_Rebuild_vs_Refine.md` first.
2. If ≥3 of the rebuild triggers fire, read `02_Bootstrap_Protocol.md`.
3. If <3 rebuild triggers fire, refine — but use the discipline from `04_Model_Execution_Rules.md` and `07_Calibration_and_Verification.md` for the refine work.

### "I want to understand how we went from 35 painful specs to 8 PASS sprints in 5 days"

Read `01_The_Epistemic_Base.md`. Specifically the eight meta-lessons:

1. Lock the architecture before you write a single cell
2. Rules over taste
3. Spec author chat ≠ plugin execution chat
4. Sprint atomicity with quantitative verification gates
5. Calibration anchors locked pre-build
6. Delete superseded rows in the same spec that supersedes them
7. By label, not by position
8. The Rule Compliance Preamble is a forcing function

Then read `08_Worked_Examples.md` to see how these compound across actual sprints.

---

## Folder structure

```
Mach33 Model Build — Epistemic Base/
├── 00_README.md                           ← you are here
├── 01_The_Epistemic_Base.md               ← headline doc (the meta-lessons)
├── 02_Bootstrap_Protocol.md               ← what to do day one
├── 03_The_23_Lessons_Learned.md           ← the WHY (principles + incidents)
├── 04_Model_Execution_Rules.md            ← the HOW (23 plugin-side rules + preamble)
├── 05_Architecture_Patterns.md            ← the architectural primitives
├── 06_Sprint_Spec_Template.md             ← drop-in template
├── 07_Calibration_and_Verification.md     ← targets, thresholds, universal protocol
├── 08_Worked_Examples.md                  ← Sprints 4/5/7/8 case studies
├── 09_When_To_Rebuild_vs_Refine.md        ← decision rule + V30.5 case
├── skills/
│   ├── README.md                          ← how to install + when it triggers
│   └── mach33-model-build-SKILL.md        ← the skill source
└── reference/
    ├── README.md                          ← provenance notes
    ├── 00_README_Sprint_Kickoff.md        ← original constitutional doc 00
    ├── 01_Lessons_Learned_FULL.md         ← original constitutional doc 01 (verbatim)
    ├── 02_Architecture_and_Methodology_FULL.md  ← original constitutional doc 02 (verbatim)
    ├── 03_Sprint_Roadmap_and_Verification_FULL.md  ← original constitutional doc 03 (verbatim)
    └── Model_Execution_Rules_FULL.md      ← original rules doc (verbatim)
```

---

## What's NOT in this folder

- **Company-specific content** — no SpaceX thesis, no Portal context, no ASTS spectrum analysis. This is the operational framework, not the investment view. Combine with `mach33-thesis-library`, `portal-context`, `tim-farrar` skills for company-specific layering.
- **The model workbook itself** — the rebuild lives at `SpaceX Model v2 SN.xlsx` (or whatever version is current). This folder describes how to build models, not the models themselves.
- **The 35 legacy V30.5 specs** — those live in the project folder's `archive/`. Useful for archaeology, not for the rebuild.
- **Chart styling, brand assets, copy conventions** — those live in `mach33-brand`, `mach33-chart-style`, `stop-slop`, `mach33-bolding`, etc.
- **External research process** — research lives in `mach33-weekly-analysis`, `mach33-newsletter-intro`, `mach33-x-post`, and the Mach33 brand stack.

---

## How to keep this folder current

When a new load-bearing lesson surfaces during a sprint:

1. Update the relevant numbered doc in this folder.
2. Update the corresponding section in `reference/` (the constitutional source).
3. Update the `mach33-model-build` skill source in `skills/` and re-install.
4. Add an entry to the relevant doc's Amendment Log.
5. Note the amendment in the Claude Log tab of the active model workbook.

Never amend silently. Future colleagues need to see what changed and why.

---

## Credit and provenance

The principles, rules, and patterns in this folder were synthesized from one full failed-and-recovered model build cycle. Specific incident credit:

- **The 23 Lessons** — synthesized from the 35-spec V30.5 build (Sprint 0 through Refine Spec 09) and the V26.1 deep audit. Each principle traces to a specific incident.
- **The 23 Execution Rules** — drafted 2026-05-18 after Spec 03 execution produced material bugs. Expanded same day. Amended 2026-05-22 after Sprint 8 results.
- **The architectural primitives** — locked 2026-05-19 in the scoping conversation between Vlad and Claude for Rebuild v2.
- **The Rule Compliance Preamble** — added 2026-05-18 after the V26.1 audit surfaced five material bugs that conservation checks didn't catch.
- **The Standing Process Rules** — added 2026-05-20 after the Sprint 0 execution attempt revealed gaps in the original protocol.
- **The worked examples** — Sprints 4, 5, 7, 8 executed between 2026-05-20 and 2026-05-22.

The pattern: every lesson here has a date and an incident. None of it is theoretical. All of it is paid for in real spec-rework hours from the V30.5 build.

---

## Related skills

- `mach33-model-build` — the skill that embeds this framework for new model chats
- `mach33-audit` — fact-checking model outputs after a sprint lands
- `mach33-chart-style` — visualisations of model output in Mach33 brand
- `mach33-thesis-library` — company-specific investment theses for SpaceX, Starlink, ODC, AI Stack
- `portal-context` — Portal Space Systems specific context for Portal model work
- `tim-farrar` — pressure-testing voice for satcom claims (Starlink, ASTS, D2D, MSS spectrum, FCC)
- `stop-slop` — eliminate AI writing patterns from any prose output
- `mach33-bolding` — bolding pass for scannability on long-form prose deliverables
