# Architecture Patterns — The Primitives

**Purpose**: Single-page cheat sheet of the architectural primitives every Mach33 modular model uses. Spec authors reference this for structural choices; the architecture spec for a new model is built by composing these primitives.

**Source**: Distilled from `02_Architecture_and_Methodology.md` in the SpaceX rebuild. The full constitutional doc lives in `reference/`.

---

## 1. Vending-machine framing — every module's P&L

Every module tab is structurally identical:

```
[Allocator IN block]      ← Cash and capacity allocated to this module
  ↓
Revenue                   ← External customer + internal-transfer revenue
COGS                      ← Direct production costs only (see below)
─────────────
Gross Profit = Module EBITDA
  ↓
CapEx                     ← Module-specific capital deployed
─────────────
Module FCF
  ↓
[Allocator OUT block]     ← Canonical labels exposed to Allocator / Group P&L / Valuation
```

**Module COGS contains exactly**:
- Constellation / fleet D&A (Starlink, ODC)
- Launch services cost (internal at-cost transfer)
- Ground ops
- Spectrum amortization (Starlink BB only)
- Terminal COGS (Starlink)
- Bandwidth services cost (ODC pays Starlink)
- Insurance
- Other COGS catch-all

**Module COGS does NOT contain**:
- R&D (any flavour) — lives on OpEx tab
- SG&A — lives on OpEx tab
- Customer service / billing — lives on OpEx tab
- Corporate overhead — does not exist anywhere
- Taxes — Group P&L only
- Facilities D&A — Corporate D&A on Group P&L

**Why this works**: Module IRR engines see only the cash flows the module itself controls. Cross-module subsidies are captured by allocator decisions, not by silently spreading overhead across modules.

---

## 2. Allocator OUT contract — 11 canonical labels

Every module tab exposes these labels at the bottom (Allocator OUT block). Order is fixed. Labels are referenced by `INDEX/MATCH` from Allocator, Group P&L, and Valuation — never by row number.

| # | Canonical label | Used by |
|---|---|---|
| 1 | `Total Revenue ($mm)` | Group P&L revenue aggregator |
| 2 | `COGS ($mm)` | Group P&L COGS aggregator |
| 3 | `Gross Profit / Module EBITDA ($mm)` | Group P&L, Allocator IRR engine |
| 4 | `EBIT ($mm)` | Group P&L (when applicable) |
| 5 | `Module CapEx ($mm)` | CapEx aggregation tab |
| 6 | `Module FCF ($mm)` | Group P&L, Valuation DCF |
| 7 | `Spot IRR` | Allocator IRR queue |
| 8 | `Forward IRR Y+2` | Allocator IRR queue |
| 9 | `Blended IRR` | Allocator IRR queue (the actual allocation weight) |
| 10 | `Capacity Demand (kg-to-LEO)` | Allocator kg queue |
| 11 | `Capital Deployed ($mm)` | Allocator cash queue feedback |

Plus per-module memo labels as needed (e.g. `Lunar Accumulated Book Value ($mm)` for SoTP terminal).

**Why this works**: When a module sprint inserts rows between OUT-block writes, the Allocator's INDEX/MATCH pulls still resolve correctly. Row numbers may shift across sprints; references stay correct.

---

## 3. Per-sat / per-launch marginal IRR engine

Every module with deployable units computes IRR per marginal unit, not per fleet.

**Cash flow stream**:
```
CF = [−CapEx_per_unit, +FCF_yr1, +FCF_yr2, ..., +FCF_yrN]
```

where each `FCF_yr_i = (revenue_per_unit − opex_per_unit − bandwidth_cost_per_unit)` for years 1..N.

**IRR variants**:
- **Spot IRR** = IRR of the CF stream starting in the current year
- **Forward IRR Y+2** = IRR of the CF stream shifted 2 years forward (captures pipeline economics)
- **Blended IRR** = `(1−w) × Spot + w × Forward`, w = 0.7 (70% forward weight)

**Economic life N**:
- N = 5 years for sat-based modules (Starlink V2 BB, V2 DTC, V3 BB, V3 DTC, ODC sats)
- N = endogenous from cadence × lifetime reuses for Customer Launch (per-launch economics)

**Strict IRR > 0 cutoff**: Modules with Blended IRR ≤ 0 get zero allocation from the cash queue. No subsidy from positive-IRR modules.

**Why this works**: Per-unit marginal economics don't depend on current fleet count. The chicken-and-egg trap (no fleet → no FCF → no IRR signal → no allocation → no fleet) disappears because IRR is computed from physics inputs (per-sat cost, per-sat revenue, per-sat bandwidth, per-sat lifetime).

---

## 4. Cash pool tracker + queue gate

The Allocator's cash machinery has three sequential operations per year:

### 4a. Cash BoY (Beginning of Year)

```
Cash BoY(N) = Cash BoY(N−1) + Group FCF(N−1) + IPO(N)
```

where Group FCF already nets OpEx + Corp CapEx + Module CapEx + Taxes (no double-counting). IPO is a one-time injection (e.g., $30B in 2027 for SpaceX).

### 4b. Strategic carve-out (deducted BEFORE queue runs)

```
Carve_out(N) = MAX(floor, prior_FCF × pct)
```

For SpaceX: Moon/Mars carve-out, pct = 15%, floor = $1B/yr (Base Case; both MC-variable). Deducted from cash pool before the IRR queue sees the remainder.

### 4c. Queue gate (LOAD-BEARING)

```
Available_for_queue(N) = MAX(0, Cash BoY(N) − Carve_out(N) − OpEx(N) − Corp CapEx(N) − Spectrum CapEx(N) − Taxes(N))
```

Reserves year-N non-module cash before module CapEx allocation. Without this gate, modules can over-claim against a phantom capital pool.

### 4d. IRR-priority sigmoid blend

```
share_i = MAX(IRR_i, 0)^k / Σ MAX(IRR_j, 0)^k
```

with k = 2. Applied to cash AND capacity (kg) queues. Strict IRR > 0 cutoff means negative-IRR modules get zero allocation.

### 4e. Deployment

```
units_deployed_i = MIN(
  cash_allocated_i / per-unit cost,
  capacity_allocated_i / per-unit mass,
  internal demand_i
)
```

The MIN ensures the module deploys only as many units as cash, capacity, AND demand simultaneously allow.

---

## 5. Strategic carve-out — no IRR engine, fixed cash claim

Some workstreams are strategic, not investment-rational (Moon/Mars for SpaceX). These do not get an IRR engine. They get:

1. A carve-out sized as `MAX(floor, prior_FCF × pct)`, deducted from cash pool before the queue.
2. Carve-out cash funds deployment via a physics-driven model (`(cash − R&D portion) / per-ship cost = ships built`).
3. Mass to LEO reserved off the top of launch capacity before the kg queue runs.
4. Book Value engine for terminal value calculation (labour units + hardware methodology).

**Why this works**: Pure IRR allocation would put zero cash into strategic workstreams forever. The carve-out is a deliberate strategic preference encoded as a hard cash claim, not a knob.

---

## 6. Internal transfers — at-cost, eliminated at Group

Whenever module A consumes output from module B (e.g., ODC consumes bandwidth from Starlink, Customer Launch consumes launch services internally):

1. **Source module (B)** books `Internal Transfer Revenue` at-cost.
2. **Consuming module (A)** books matching `Internal COGS` at-cost.
3. **Group P&L** has an `Inter-Module Eliminations` block that subtracts the flow once so consolidated Revenue and FCF aren't double-counted.
4. **Conservation check row** verifies: `Σ Source internal rev = Σ Consuming module COGS for the flow` at every year.

**Why "at-cost"**: At-market internal transfer pricing would give the source module a margin on the internal flow, which doesn't represent any real cash to SpaceX consolidated. At-cost keeps module IRR engines honest about what cash they actually generate.

**Why count gross at module level**: Module IRR engines need to see the full cost of services consumed (so consuming module's IRR reflects reality) and the full revenue of services provided (so source module's IRR reflects reality). Elimination happens once, at Group, to fix consolidated reporting.

---

## 7. Vehicle / launch build cost — non-module claim at allocator gate

For models with a launch vehicle (Starship, Falcon, etc.), vehicle build cost is NOT in any module's CapEx. It is a **forward-aggregate-demand-sized non-module cash claim** deducted at the allocator queue gate.

**Sizing formula**:
```
Vehicle_build_cost(N) = (Σ forward_N_kg_demand_across_consumers / payload_per_launch / launches_per_vehicle_per_year) × build_cost_per_vehicle
```

Sum the forward kg demand across all consumers (Starlink launches, ODC launches, customer launches, Lunar Mars missions). Divide by payload per launch and launches per vehicle per year to get the vehicle count needed. Multiply by build cost.

**Vehicle D&A** flows back to consumer modules via at-cost launch services transfer pricing (same internal-transfer pattern as Section 6).

**Why this works**: Routing vehicle build through Customer Launch CapEx distorts Customer Launch's per-launch IRR (it absorbs all vehicle build cost while only servicing some of the demand). Treating vehicle build as a non-module claim — sized by aggregate forward demand — keeps the Customer Launch IRR engine honest.

---

## 8. Year-offset helper row + anchor-and-offset formula pattern

**Every tab with year columns** gets a year-offset helper row directly below the year header row. Static integers, hardcoded, not chained:

```
Row 4 (year header):   2025  2026  2027  ...  2049  2050
Col:                   D     E     F          AB    AC
Row 5 (year offset):   0     1     2          24    25
```

**Every deterministic ramp formula** uses anchor-and-offset:

```
D14  = =Assumptions!$B${start_input}                      (anchor at start year)
E14  = =$D$14 × (1+Assumptions!$B${cagr})^E$5             (anchor + offset)
F14:AC14 = copy E14 across (E$5 shifts correctly)
```

**Never use recursive prior-column references** like `E14 = D14 × (1+rate)`. Row moves break the chain. Row insertions cascade silently. Bug-prone.

**Year-chained logic exception**: Genuinely year-chained logic (`EoY subs = BoY subs + Net adds`, `Cumulative CapEx = prior cumulative + this-year CapEx`) has to chain. Mark these explicitly with a comment in the spec.

---

## 9. Cross-tab references — INDEX/MATCH on labels

Every cross-tab pull resolves by label:

```
=INDEX(Module!D:D, MATCH("Module FCF ($mm)", Module!$A:$A, 0))
```

**Never** use hardcoded row numbers like `=Module!D210`. Row numbers shift across sprints; references silently point at the wrong concept.

**Year column resolved by offset**:
```
=INDEX(Module!$D:$AC, MATCH("Module FCF ($mm)", Module!$A:$A, 0), D$5+1)
```

where `D$5+1` translates the year offset (0-based) into the column index (1-based for INDEX).

---

## 10. Tab structure — locked for SpaceX rebuild v2

12–14 tabs depending on AI Stack resolution:

| Tab | Function |
|---|---|
| Assumptions | All behaviour inputs with MC ranges |
| Allocator | Cash + capacity queues, queue gate, internal flows |
| Launch Capacity | Vehicle inventory, launch cadence, kg capacity |
| Customer Launch | External customer launch services revenue + per-launch IRR |
| Starlink | Subscription revenue + per-vehicle IRR (V2/V3, BB/DTC) |
| Starlink Capacity | Bandwidth supply, ODC bandwidth allocation, demand cap |
| ODC | Orbital data centre — cash-driven deployment + per-sat IRR |
| AI Stack | (Standalone) AI products + per-product IRR, buys compute at-cost from ODC |
| Lunar Mars | Strategic carve-out — no IRR engine, BV engine for terminal |
| Group P&L | Consolidation, eliminations, conservation checks |
| OpEx | R&D + SG&A + corporate overhead lives here, not on modules |
| CapEx | CapEx aggregation across modules + corporate CapEx |
| Valuation | DCF, terminal value, SoTP |
| Claude Log | Sprint-by-sprint append-only log of what landed |

**No Dashboard** (retired after V26.1 audit — three bugs in cross-tab pulls).
**No ISM** (cut from rebuild — never had a locked function).

---

## 11. Iterative calc — on, with discipline

Within-year cycles (Starlink ↔ Starlink Capacity %  × Revenue; Sprint 8 OpEx ↔ Module CapEx; etc.) require iterative calc.

**Settings**: 100 iterations, 0.001 tolerance.

**Discipline**:
- Every within-year cycle is documented in the architecture spec with justification.
- Prefer prior-year references to break circularity (e.g., Mars carve-out uses prior-year FCF, not current-year).
- Every sprint verification includes a 5x round-trip recalc stability test: no value should move >$1M.
- If a value oscillates across recalcs, the cycle is bistable and must be redesigned.

---

## 12. Monte Carlo posture

**Build with point estimates**. No MC sampling during the build sprints (Sprint 0–N+4).

**MC ranges layered at end**: Each Assumptions input has its MC Min / MC Max / MC Distribution columns populated at row creation. The MC sprint (Sprint N+5) wires the engine against the existing register — it does not retro-populate ranges.

**Scenarios after MC**: Bear / Base / Bull scenarios are post-MC conditional cuts of the distribution, not pre-MC point estimates. Point-estimate scenarios pre-MC are arbitrary; thesis-conditional cuts post-MC are defensible.

---

## 13. Calibration anchors locked pre-build

The architecture spec includes the calibration target table for year zero (typically the latest disclosed full year). For SpaceX rebuild v2:

| Target | Value | Tolerance |
|---|---|---|
| Group Revenue 2025 | $14.65B | ±5% |
| Group EBITDA 2025 | $8.69B | ±5% |
| Group FCF 2025 | $3.67B | ±5% |
| F9 launches 2025 | 171 | ±5% |
| Starlink+DTC revenue 2025 | $7.85B | ±5% |
| Constellation D&A 2025 | $707M | ±10% |
| Total OpEx 2025 | $4.48B (post-Sprint 8.5) | ±5% |
| Total Module CapEx 2025 | $1.24B (vehicle build at Allocator) | ±5% |
| Total Group CapEx 2025 | $7.03B (with Vehicle Build claim Sprint 10+) | ±5% |
| Module-specific anchors | Per module sprint spec | per spec |

Every sprint that produces year-zero outputs must hit its anchors within tolerance. Deviation triggers retune in the same sprint or the next patch sprint. Never "audit later."

---

## How to apply

When drafting the architecture spec for a new model:

1. Lock the tab list (Section 10).
2. Apply vending-machine framing to every module (Section 1).
3. Define the Allocator OUT contract — 11 canonical labels (Section 2).
4. Specify the per-unit IRR engine for every deployable-unit module (Section 3).
5. Build the cash pool + queue gate + carve-out (Sections 4, 5).
6. Specify every internal transfer with the four-step pattern (Section 6).
7. Decide where vehicle / launch build cost lives (Section 7).
8. Mandate year-offset helper rows and anchor-and-offset formulas everywhere (Section 8).
9. Mandate label-based cross-tab references (Section 9).
10. Enable iterative calc with documented cycles (Section 11).
11. Plan MC layer at end, scenarios after MC (Section 12).
12. Lock calibration anchors from the latest disclosed full year (Section 13).

All twelve before Sprint 1 runs. See `02_Bootstrap_Protocol.md` for the full bootstrap sequence.

---

## Related

- `02_Bootstrap_Protocol.md` — what to do day one
- `03_The_23_Lessons_Learned.md` — why these patterns exist
- `04_Model_Execution_Rules.md` — how to implement them safely
- `08_Worked_Examples.md` — case studies of sprints that applied these patterns
- `reference/02_Architecture_and_Methodology_FULL.md` — verbatim source from SpaceX rebuild
