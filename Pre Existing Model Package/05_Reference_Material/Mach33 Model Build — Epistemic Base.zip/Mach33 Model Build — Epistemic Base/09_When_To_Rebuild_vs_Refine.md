# When to Rebuild from Scratch vs Refine

**Purpose**: A decision rule for when to abandon an existing model and rebuild rather than keep refining it. The V30.5 → Rebuild v2 transition is the canonical case study.

---

## The decision

You have an existing model that needs work. Three options:

1. **Refine** — add the new feature / fix the bug inside the existing workbook
2. **Rebuild from scratch** — abandon the existing workbook; constitutional bootstrap; fresh sprints
3. **Hybrid** — keep the existing workbook for one use case while rebuilding for another (e.g., S-1 historicals workbook alongside the projection rebuild)

The default should be refine. Rebuilds are expensive — full bootstrap protocol, fresh sprints, recalibration, owner re-onboarding. But the refine path becomes more expensive than rebuild past a certain threshold of drift.

## The rebuild triggers

If any THREE of these are true, rebuild from scratch:

1. **Load-bearing methodology has changed across 10+ specs**. Vending-machine framing, IRR engine refactor, allocator restructure, OFFSET purge — each requires retrofitting across every module tab. Past 10 such retrofits, the cumulative cost exceeds the rebuild cost.
2. **The stale residue map exceeds ~200 cells**. Stale rows accumulate when methodology is superseded but the old rows are left "for later cleanup." Past 200, the model becomes harder to read than to rewrite.
3. **The owner has lost confidence in the existing model's outputs**. This is the most important trigger. If Vlad (or your owner) says "I don't trust this number," and you cannot point at a specific cell-by-cell explanation, the model has crossed the trust threshold.
4. **A planned change touches the entire workbook architecture**. Adding a new top-level concept (strategic carve-out, new module type, new internal flow pattern) that cascades through every tab. The refine cost approaches the rebuild cost.
5. **Calibration anchors have shifted and the model needs full re-tuning**. New disclosure (S-1, 10-K, funding round) replaces the old anchor table. Refining to new anchors when the model wasn't calibrated to anchors in the first place is harder than rebuilding to the new anchors from day one.

## The V30.5 case study

On 2026-05-19, Vlad made the call to rebuild the SpaceX model from scratch rather than continue refining V30.5. Here is what triggered the decision, mapped to the criteria above:

### Trigger 1 — Load-bearing methodology had changed across 10+ specs

Three load-bearing methodologies arrived late in the V30.5 build:
- **Vending-machine framing** arrived at Refine Spec 01 (spec 12 overall). Every module tab needed to be retrofitted to strip R&D, SG&A, corporate overhead, and taxes.
- **Per-sat marginal IRR** arrived at Spec 08 / Spec 09 Patch P/M (spec 30+). Fleet-level MFW-IRR had to be retired across every deployable-unit module.
- **Allocator queue gate** arrived at Spec 06+07. Sprint 5's sigmoid + Layer 3 sweep had to be killed; rows R83-R104 cleared; the legacy R10-R21 block on Assumptions blanked.

Three load-bearing changes, each requiring 3–5 sprints of retrofit. Total retrofit cost ≈ 12 sprints. By comparison, the architectural cost of locking these methodologies day one in the rebuild was ≈ 1 sprint (Sprint 0 architecture spec).

### Trigger 2 — Stale residue map exceeded 200 cells

The `Stale_Row_Map.md` doc, written 2026-05-19 as input to the rebuild decision, catalogued 200–400 cells likely still stale in V30.5:
- Sprint 5 sigmoid rows R20–R37 cleared but left in place with `[Legacy — cleared]` labels
- Layer 3 sweep rows R83–R104 cleared but still present
- AI Stack tab decorative skeleton (whole tab dormant for 35 spec days)
- Sprint 5.6 NIC inputs decorated post per-sat IRR refactor
- ISM tab cut but cross-tab references not all removed

By the time the audit landed, the residue had become the dominant signal — every spec had to navigate around stale cells the prior specs had left behind.

### Trigger 3 — Owner had lost confidence

Vlad's exact framing 2026-05-19: "I'm getting stressed out, there's so much stale shit in it."

When the owner has lost confidence, the model is no longer usable as a decision-making tool. Refining a model the owner does not trust produces a more refined model the owner still does not trust. The trust threshold had been crossed.

### Trigger 4 — Planned changes touched the entire architecture

The pre-IPO deadline required:
- Moon/Mars treated as strategic carve-out (architectural, touches Allocator)
- AI Stack as standalone module (architectural, touches tab list + Allocator queue + Group P&L)
- Vehicle build cost as non-module Allocator claim (architectural, touches Customer Launch + Allocator + CapEx)
- Q4'25 calibration anchors as the binding target set (architectural, touches every module's verification gate)

Four architectural changes in parallel. Refining V30.5 to absorb all four would have required retrofitting every tab. Rebuilding lets the new architecture be specced day one.

### Trigger 5 — Calibration anchors had shifted

The Q4'25 CLEANUP model became available 2026-05-19 as the anchor source. V30.5 had no anchored 2025 outputs (Sprint 11 was supposed to retune Mars/Moon labour productivity to close a 10× BV undershoot vs a *speculative* spec target). Refining V30.5 to be calibrated to Q4'25 was harder than building from scratch against Q4'25 day one.

### The decision

Five triggers all hit. Vlad called the rebuild on 2026-05-19. Within 5 days, the rebuild had:
- Five constitutional documents drafted and locked
- Sprint 0 (architecture + Assumptions skeleton) PASS
- Sprint 1 (Assumptions populated) PASS
- Sprint 2 (Launch Capacity) PASS
- Sprint 3 (Customer Launch) PASS
- Sprint 4 (Starlink) PASS 14/15
- Sprint 4.5 (patch) absorbed into Sprint 5 prep
- Sprint 5 (ODC + Sprint 4.5 patch) PASS
- Sprint 7 (Lunar Mars) PASS
- Sprint 8 (OpEx + CapEx + Sprint 3.6 patch) PASS-with-overshoot, fully decomposed
- Sprint 8.5 (retune) specced and ready

By comparison, V30.5 took 11 days to reach Spec 06+07 (the equivalent allocator landing) and 35 specs across 17 days to reach a state we then abandoned. The rebuild is on track to close in roughly one third the calendar time of the first build, with a workbook we trust.

---

## When to refine instead

The default. If none of the rebuild triggers fire, refine the existing model. Specifically:

- The change is bounded to 1–3 tabs.
- Calibration is broadly hitting; the change is to update an assumption or add a sub-component.
- The owner has confidence in the existing model and just wants a layer added.
- The cost of refining is bounded and known; the cost of rebuilding is high and unknown.

Most planned model changes fit this profile. Don't reach for rebuild as the first response — it is the last response.

---

## Hybrid — keep one model for one use case, rebuild for another

Sometimes the answer is both. Examples from the SpaceX rebuild:

- **S-1 historicals workbook** built in a separate chat alongside the projection rebuild. S-1 historicals need the audited 2024 disclosure; the rebuild projects from 2025 forward. Two workbooks, two purposes, no overlap.
- **AI Stack parallel build** — Stage 1 architecture scoping doc shipped 2026-05-22 alongside Sprint 7 and Sprint 8. Stage 2 plugin execution happens when 8 open questions are answered. The main rebuild doesn't wait for AI Stack; AI Stack doesn't block the main rebuild.

The hybrid pattern works when:
- The two workstreams have minimal shared state.
- Each can be specified with its own constitutional framework.
- The ownership / sign-off on each is clear.

When it doesn't work: when the two workstreams keep writing to the same cells. Then you have version-control hell instead of a rebuild.

---

## What to do with the old model after a rebuild

The old model is reference, not active build. Specifically:

1. **Move to an `archive/` subfolder**. Don't delete — there will be questions about how the old model handled X that only the old workbook can answer.
2. **Catalogue the stale-row map** (which rows in the old model represented superseded methodology). Useful for any future spec that wants to confirm "we are not repeating X."
3. **Anchor extraction** — if the old model had hand-tuned values that should be inherited (e.g., calibration anchors, Wright's Law learning rates), extract them into a separate "Anchors from Old Model" doc.
4. **Don't open the old workbook in the same Cowork session as the rebuild**. Different Save-As names, different folders, different mental contexts. Cross-contamination is a real risk.

For SpaceX rebuild v2, the old V30.5 lives at `SpaceX Model V30.5.xlsx` alongside the rebuild workbook. The 35+ legacy spec docs live in `archive/legacy-build-2026-05-08-to-05-19/`. The stale-row map lives at `Stale_Row_Map.md`. None of it gets read during a sprint chat unless explicitly needed for archaeology.

---

## The cost of getting the decision wrong

**False-positive rebuild** (rebuild when refining would have worked): wasted 1–2 weeks of bootstrap + early sprint time. Painful but recoverable.

**False-negative rebuild** (refine when rebuilding was needed): continued accumulation of stale residue and drift. The owner's trust degrades further. Each new refine becomes harder. Eventually you have to rebuild anyway, at higher cost, with worse calibration.

Bias is toward rebuild when in doubt. The V30.5 case shows the rebuild cost was bounded (5 days to clear 8 sprints) while the continued-refine cost was unbounded (35 specs and counting, with no end in sight).

---

## Related

- `01_The_Epistemic_Base.md` — meta-lesson 1 (architectural lockings day one) is the principle that makes rebuilds cheaper than continued refines past the drift threshold
- `02_Bootstrap_Protocol.md` — what to do once you've decided to rebuild
- `08_Worked_Examples.md` — concrete Sprint 4/5/7/8 outputs from the rebuild
- `reference/01_Lessons_Learned_FULL.md` — full V30.5 incident catalogue that drove the decision
