# Sprint Spec Template

**Purpose**: Drop-in template for a new sprint spec. Copy this file, rename to `Sprint_N_Spec.md`, fill in the brackets, and run.

**Usage**: Spec author chats use this as the structural starting point. Plugin execution chats read the resulting spec and execute against it.

---

# Sprint N Spec — [Sprint Name]

**Status**: Draft / Ready for execution / Executed PASS / Executed FAIL
**Author**: [Name]
**Date**: [YYYY-MM-DD]
**Target workbook**: [Vlad pre-names via Save-As — e.g. `Model_v2_SN.xlsx`]

## Rule Compliance Preamble (mandatory)

This spec follows `Model Execution Rules.md` and the four constitutional docs. Confirm each before execution:

- [ ] **Rule 1** (one concept per write) — section structure separates labels, formulas, formats.
- [ ] **Rule 3 / 23** (formula pattern) — bounded-CAGR / ramp formulas use anchor-and-offset. Year-chained formulas explicitly flagged as Rule 23 exceptions with one-line justification.
- [ ] **Rule 4** (verification gate) — every section has explicit read-back cells (D, I, S, AC) + expected values.
- [ ] **Rule 6** (inline formulas) — every cell write specified with the full Excel formula, not a convention reference.
- [ ] **Rule 10** (no row insertions) — confirm no `insert_row` operations; all new content appended below existing data.
- [ ] **Rule 11** (touch points) — every new line item lists its SUM range / aggregator / conservation check / Valuation pulls.
- [ ] **Rule 12** (label-based cross-tab refs) — any Allocator / Valuation / Group P&L pulls use INDEX/MATCH on label.
- [ ] **Rule 13** (vending-machine test) — no module tab gets R&D / SG&A / overhead / taxes added.
- [ ] **Rule 14** (no hardcoded constants) — every behaviour input lives on Assumptions.
- [ ] **Rule 15** (sanity check halt thresholds) — every sanity check has a quantitative halt condition.
- [ ] **Rule 19** (save-as) — Vlad handles all saving; spec contains no save instructions.
- [ ] **Rule 22** (stale-ref scan) — Valuation + Allocator + Group P&L scan listed in §Verification.

Architecture & Methodology compliance:

- [ ] Module P&L follows vending-machine framing (Architecture §3).
- [ ] Per-sat / per-launch marginal IRR engine (Architecture §5), not fleet-level MFW-IRR.
- [ ] Allocator OUT contract uses canonical labels (Architecture §4.2).
- [ ] Year-offset helper row at row 5 + year header at row 4 on every tab with year columns.
- [ ] ZERO `OFFSET()` formulas; INDEX:INDEX patterns used for dynamic ranges (Principle 11).

If any box is unchecked, the spec author justifies or amends before execution starts.

---

## §0 — Sprint scope summary

[One-paragraph plain-English description of what this sprint does and why it is needed now.]

**Dependencies**: [Which prior sprints must have landed PASS. Which canonical labels this sprint reads from upstream modules. Which workbook version is the starting point.]

**Tabs touched**: [List every tab this sprint writes to. If a tab is read-only for this sprint, note "read-only".]

**Out of scope** (explicit): [What this sprint does NOT do. Reduces ambiguity in execution.]

---

## §1 — Inputs added to Assumptions

[Inline table of new Assumptions rows. Every row has: Cell ref, Label, Base Case value, MC Min, MC Max, MC Distribution, Notes. No retrofitting MC ranges in later sprints — populate at creation.]

| Cell | Label | Base Case | MC Min | MC Max | Distribution | Notes |
|---|---|---|---|---|---|---|
| B[XXX] | [Label] | [value] | [min] | [max] | triangle / lognormal / uniform / discrete / structural | [source / calibration anchor / "structural — locked"] |

**Touch points** (Rule 11):
- New rows: B[XXX] through B[YYY]
- SUM range to expand: [if applicable]
- MC register: rows added inline (no separate register sprint)

**Verification gate (Assumptions)**:
- Read B[XXX]:B[YYY]. Confirm values match table above.
- Read no downstream consumers yet — this section is inputs only.

---

## §2 — [Module / Tab name] body

[For each tab the sprint writes to, a section like this.]

### §2.1 — Section setup (column A labels, year header check)

[Labels written in one tool call per Rule 1.]

**Cell writes** (column A only):
- A[XX] = "[Label text]"
- A[YY] = "[Label text]"
- ...

**Verification gate (labels)**:
- Read A[XX]:A[YY]. Confirm labels match.

### §2.2 — [Sub-section name, e.g. Revenue block]

[Inline formula writes per Rule 6. Every formula stated in full, not as "use the CAGR pattern."]

**Cell writes**:
- D[XX] = `=[full Excel formula]`
- E[XX] = `=[full Excel formula]`
- copyToRange source=E[XX] destination=F[XX]:AC[XX]

(Repeat for each row.)

**Touch points** (Rule 11):
- New row XX → SUM at row [Total row]; expand from [old range] to [new range]
- Group P&L pull at row [YY]: update INDEX/MATCH label if changed
- Conservation check at row [ZZ]: ensure new flow is captured

**Verification gate (section)**:
- Read D[XX], I[XX], S[XX], AC[XX] (year-zero, 2030, 2040, 2050)
  - Expected: D[XX] = [value]; I[XX] = [value]; S[XX] = [value]; AC[XX] = [value]
- Read Group P&L D108:AC108 (or your conservation row). Every cell must = "OK".
- If sanity check fails, halt per Rule 15.

### §2.3 — IRR engine (if applicable)

[Per-unit marginal IRR formula. Cash flow stream `[−CapEx_per_unit, +FCF_yr1, ..., +FCF_yrN]`. Spot, Forward Y+2, Blended IRR rows. IFERROR-0 guard for pre-revenue years.]

**Cell writes**:
- D[XX] (Spot IRR) = `=IFERROR(IRR(INDEX(...):INDEX(...)), 0)`
- D[YY] (Forward IRR Y+2) = `=IFERROR(IRR(INDEX(...):INDEX(...)), 0)`
- D[ZZ] (Blended IRR) = `=0.3*D[XX] + 0.7*D[YY]`
- copyToRange across all three rows

**Verification gate (IRR)**:
- Read Spot IRR, Forward IRR, Blended IRR at D, I, S, AC.
  - Expected at D (year zero): [value or "0" if pre-revenue]
  - Expected at I (2030): [value]
  - Expected at S (2040): [value]
  - Expected at AC (2050): [value]
- Confirm Blended IRR > 0 in years where module is allocating cash. Halt if negative in active deployment years.

### §2.4 — Allocator OUT block (canonical labels)

[Append the canonical 11 labels at the bottom of the tab. INDEX/MATCH-discoverable from Allocator / Group P&L / Valuation.]

**Cell writes** (column A — labels):
- A[201] = "Total Revenue ($mm)"
- A[202] = "Gross Profit / Module EBITDA ($mm)"
- A[203] = "EBIT ($mm)"
- A[204] = "Module FCF ($mm)"
- A[205] = "Module CapEx ($mm)"
- A[207] = "Spot IRR"
- A[208] = "Forward IRR Y+2"
- A[209] = "Blended IRR"
- A[210] = "Capacity Demand (kg-to-LEO)" (or equivalent)
- A[211] = "Capital Deployed ($mm)"
- A[212] = "[any per-module memo label]"

**Cell writes** (formulas — pull from module body):
- D[201]:AC[201] = INDEX/MATCH pull from Total Revenue row in body
- (repeat for each)

**Verification gate (Allocator OUT)**:
- Read D[201]:D[212]. Confirm each canonical label resolves to the right body row.
- From a different tab, attempt an INDEX/MATCH pull on each label. Confirm resolves correctly.

---

## §3 — Downstream consumer updates (if applicable)

[If this sprint adds new labels that downstream tabs need to read, list the consumer updates.]

**Group P&L**:
- New row [XX] = `=INDEX('[Module]'!$D:$AC, MATCH("[Label]", '[Module]'!$A:$A, 0), D$5+1)`
- (etc.)

**Valuation**:
- New row [YY] for SoTP terminal: `=INDEX('[Module]'!$D:$AC, MATCH("[BV Label]", '[Module]'!$A:$A, 0), AC$5+1)`

**Verification gate (downstream)**:
- Read each new consumer row at D, I, S, AC. Confirm values match upstream module values.

---

## §4 — Conservation checks

[Every internal flow added by this sprint gets a conservation check row on Group P&L.]

**New conservation rows**:
- Row [XX]: `=SUM([source module internal transfer rev range]) - SUM([consuming modules internal COGS range])`. Should = 0 within $1mm tolerance.

**Verification gate (conservation)**:
- Read each new conservation row at D, I, S, AC. Confirm all = 0 within $1mm.
- Read overall conservation row D108:AC108. Every year must = "OK".

---

## §5 — Stale-reference scan (Rule 22)

**Cells to scan**:
- Valuation tab: every cross-sheet pull. For each, verify the source cell's column-A label matches what Valuation labels the pull as.
- Allocator tab: every per-module pull row. For each, verify the source cell's column-A label matches the canonical Allocator OUT label.
- Group P&L: every cross-sheet pull added or modified by this sprint.

**Halt condition**: Any label/source mismatch → stop, report.

---

## §6 — Calibration anchors + halt thresholds

[Quantitative pass/fail targets for this sprint. Sourced from the architecture spec's calibration table.]

| Anchor | Target value | Tolerance | Halt condition |
|---|---|---|---|
| [Module Revenue year-zero] | [$X M] | ±5% | Outside [$X×0.95, $X×1.05] → halt |
| [Module EBITDA margin year-zero] | [Y%] | ±X percentage points | Outside range → halt |
| [Module IRR year-zero] | [Z%] | within range | If pre-revenue, expected = 0 (IFERROR-0 guard) |
| ... | ... | ... | ... |

**Sanity checks** (Rule 15):
- [Specific sanity check with quantitative halt threshold, e.g. "Implied subs < 15M; halt above"]
- [Specific sanity check]

---

## §7 — Final verification (universal protocol)

Run end of sprint, before declaring done:

1. **Workbook-wide error scan**: `#REF!`, `#VALUE!`, `#DIV/0!` — zero results.
2. **Conservation block**: D108:AC108 all "OK". (Or your model's conservation row.)
3. **Internal flow conservation**: Every conservation row from §4 = 0 within $1mm.
4. **Allocator OUT label-based references resolve correctly**: per-label INDEX/MATCH test.
5. **Vending-machine test**: Module Allocator OUT EBITDA = Gross Profit on every module tab touched.
6. **Stale-reference scan**: per §5.
7. **5x round-trip recalc stability**: no value moves >$1M across 5 sequential F9 recalcs.
8. **Calibration targets hit**: per §6, every anchor within tolerance.
9. **Claude Log entry**: append row to Claude Log tab with sprint number, date, tabs touched, summary, outstanding items.

---

## §8 — Out-of-scope / deferred to next sprint

[Anything noticed during this sprint that doesn't fit in scope. Captured here so the next sprint's author has it.]

- [Item 1]
- [Item 2]

---

## §9 — Amendments to constitutional docs (if any)

[If this sprint surfaces an architectural fact that the constitutional docs got wrong, list the amendments here. Update the constitutional doc and its Amendment Log in the same chat.]

- [None] / [Architecture §X.Y amendment: ...]

---

## Appendix A — Build Plan tables (if applicable)

[For Assumptions tab sprints or other input-heavy sprints, inline the full input table here. Don't reference an external XLSX — the plugin can't read external files.]

---

## Appendix B — Glossary additions (if any)

[New canonical labels or new tab names introduced by this sprint, added to the architecture spec's glossary.]

---

# End of spec

When this spec is complete and the Rule Compliance Preamble has all boxes ticked, hand it to a fresh plugin execution chat with the kickoff prompt template (see `00_README.md` in this folder, or your model's `00_README_Sprint_Kickoff.md`).
