# The Epistemic Base — Building Complex Financial Models with AI, the Mach33 Way

**Author**: Vlad Saigau (Mach33) + Claude, synthesized from the SpaceX Model V30.5 → Rebuild v2 transition (May 2026).
**Audience**: Any Mach33 colleague about to build, rebuild, or substantially refactor a modular valuation model with AI assistance.
**Read time**: 25 minutes.

This is the "why" doc. It is the meta-lesson layer: what we learned about *how to direct AI to build a model*, distilled from one full failed-and-recovered cycle. The "what to do" lives in the supporting docs in this folder; this doc explains the worldview underneath them.

---

## The headline

We built the SpaceX model twice. The first time took 35 specs across 11+ days and ended with a workbook nobody trusted. The second time — running for ~5 days at the time of writing — has produced PASS calibrations on 8 of 12 sprints, with every meta-failure mode of the first iteration designed out of the workflow before any cell was written.

The difference is not better AI. It is the same Claude. The difference is that we now treat the model build as a *constitutional construction project* rather than a *conversational refinement loop*. Eight meta-lessons capture what changed.

---

## Meta-lesson 1 — Lock the architecture before you write a single cell

The single most expensive failure mode of the first build was *postponed architectural decisions*. Vending-machine framing — the rule that every module's P&L stops at Module EBITDA and never carries R&D, SG&A, overhead, or taxes — arrived at spec 12. Per-sat marginal IRR — the only IRR formulation that works for pre-revenue modules — arrived at spec 30. The Allocator queue gate that reserves non-module cash before module CapEx allocation arrived at spec 6+7. Each of these required 3–5 sprints of retrofit across every module tab that had been built without them.

The rebuild treats the architecture spec as a *constitutional document* that gets drafted before sprint 1 runs. It locks the module list, the P&L structure, the IRR formulation, the allocator architecture, the cross-tab discipline, the year horizon, the calibration anchors. Sprint specs that want to deviate must update the architecture document first and explain why.

The mental shift: stop letting load-bearing methodology emerge from the sprint conversation. Force it out of yourself before you start. If you cannot answer a structural question (how does AI Stack relate to ODC? standalone module or rolled in?) the day you start, you cannot answer it after building three sprints of dependent code either — you will have just made the answer more expensive to discover.

**Practical implication for colleagues**: When starting any new model, your first deliverable is not a tab — it is the five constitutional documents (see `02_Bootstrap_Protocol.md`). No exceptions.

---

## Meta-lesson 2 — Rules over taste

Sprint 3 of the first build went sideways because the plugin executed a single tool call that mixed column-A labels with column-D formulas; the tool interpreted the bounding box as a source pattern and tiled labels across the column, overwriting the formulas it had just written. The bug took two patches to fix. The root cause was not stupidity — it was an unstated convention. The fix was a written rule: *one concept per write*.

That rule plus 22 others now lives in `Model Execution Rules.md`. Every spec opens with a 12-box Rule Compliance Preamble that the spec author ticks before the spec is valid for execution, and the plugin refuses to start work if any box is unchecked without justification.

Why this works: AI assistants are highly capable of following written rules, and highly capable of forgetting unwritten conventions. If you have a convention you care about, write it down as an enforceable rule, give it a number, and check it before every spec. Taste is not transferable across conversations; rules are.

The 23 rules are not arbitrary — each one traces to a specific incident in the first build. When you find yourself making the same correction to Claude three times, that is your signal to write rule 24.

**Practical implication**: Treat the rules doc as living code. When a new failure mode surfaces, add a rule with the date and the incident. The doc gets better; the failure mode does not repeat.

---

## Meta-lesson 3 — Spec author chat ≠ plugin execution chat

The first build mixed scoping, drafting, and execution in the same conversation. Specs drifted as Claude tried to remember what was decided three messages ago. Execution decisions leaked back into the spec retroactively. Audit trails became impossible to reconstruct.

The rebuild separates the two:

- **Spec author chat** — Claude helps Vlad scope a sprint, drafts `Sprint_N_Spec.md`, references the constitutional docs, fills in the Rule Compliance Preamble. Output is a self-contained markdown document.
- **Plugin execution chat** — Fresh Claude reads only the spec, refuses to start without the preamble, executes the writes against the live workbook, runs the verification gates, appends to the Claude Log tab. No filesystem reads, no other docs.

The separation forces specs to be self-contained. If the spec references a Build Plan XLSX or a memory file or an external paragraph from a constitutional doc, the plugin chat — which has no memory of any of that — will halt at pre-flight. That halt is a feature: it tells you the spec was not actually finished.

**Practical implication**: Draft specs in one chat. Execute in a fresh chat. Use the kickoff prompt template (see `06_Sprint_Spec_Template.md`) as the literal first message in the execution chat. If the plugin halts at pre-flight, fix the spec, do not paper over the gap with conversational glue.

---

## Meta-lesson 4 — Sprint atomicity with quantitative verification gates

The first build's sprints were "the next big thing we need to do." Sprint 5 was a multi-week sigmoid-and-Layer-3-sweep undertaking that touched five tabs and was never properly verified because the verification surface was too large by the time it was done.

The rebuild defines a sprint as one tab (one module, or one cross-cutting tab, or the allocator) with a fixed scope, fixed acceptance criteria, and a fixed verification protocol. The Sprint Roadmap lists 12 sprints; each one is a half-day to one-day unit of work. Each sprint has its own calibration anchors, its own halt thresholds, its own canonical labels it must publish for downstream consumers.

Every section of every spec has a verification gate at the end: read back cells D (2025), I (2030), S (2040), AC (2050); compare against expected; halt if any deviation exceeds tolerance. Conservation checks run after every section, not just at the end. Stale-reference scans run as the final verification step of every sprint.

The thing this prevents: silent drift. The thing this enables: confidence. After Sprint 5 lands with PASS on every calibration anchor, you do not wonder whether the next sprint can build on top of it.

**Practical implication**: Define your sprints small. Specify the read-backs. Set the halt thresholds. Push back when Claude proposes to "verify at the end" — that is the failure mode you are designing against.

---

## Meta-lesson 5 — Calibration anchors locked pre-build, in the architecture spec

The first build had no anchored 2025 outputs. Sprint 11 was supposed to retune Mars/Moon labour productivity to close a 10× book-value undershoot against a spec target that was itself speculative. There was no way to know if the model was right because we had not committed to what right looked like.

The rebuild commits to a calibration target set on day one — for the SpaceX rebuild, the Q4'25 CLEANUP model gives us Group Revenue $14.65B, Group EBITDA $8.69B, FCF $3.67B, F9 launches 171, and 30+ more anchors. Every sprint that produces 2025 outputs must hit its relevant anchors within ±5%. Deviation triggers a retune in the same sprint or the next patch sprint — not "audit later."

The anchors are not aspirational. They are the disclosed historicals from a real, audited financial picture. The model is calibrated to reality before it is asked to project from reality.

**Practical implication**: For any new model (Portal, ASTS, next SpaceX iteration), the first deliverable inside the constitutional docs is the calibration anchor table. Q4 financials, latest 10-K, S-1, last funding round disclosure — whatever the most credible recent-actuals source is. Locked before Sprint 1 starts.

---

## Meta-lesson 6 — Delete superseded rows in the same spec that supersedes them

This is the rule that drove the rebuild decision. The first build accumulated stale residue across 35 specs: Sprint 5 sigmoid rows cleared but left in place with `[Legacy — cleared]` labels; Layer 3 sweep rows R83-R104 blanked but still occupying space; AI Stack ghost tab with decorative skeleton rows; ISM tab cut but referenced by other tabs that never had their pointers removed. By the time we audited V30.5, the stale-row map catalogued 200–400 cells likely still stale, and the model was no longer trustable.

The rebuild rule: when a methodology is superseded, the spec that supersedes it also deletes the prior rows. No "later cleanup" sprints. No `[Legacy]` markers on rows that have been replaced.

This is operationally annoying because it means specs are longer (every replacement spec includes the deletion plan), but it is the single largest contributor to a model staying clean over time. Stale residue compounds; one stale row makes the next one easier to leave behind.

**Practical implication**: When Claude proposes to "leave R83 in place with a TODO," push back. The spec is not done until the deletion is in it.

---

## Meta-lesson 7 — By label, not by position

Every cross-tab reference in the rebuild uses `INDEX(Module!D:D, MATCH("label", Module!$A:$A, 0))`. Zero hardcoded `=Module!D210` references anywhere. This is enforced by Rule 12 and the Allocator OUT contract, which fixes 11 canonical row labels every module tab must expose (Total Revenue, COGS, Gross Profit / Module EBITDA, EBIT, CapEx, Module FCF, Spot IRR, Forward IRR Y+2, Blended IRR, Capacity Demand, Capital Deployed).

The first build's most-painful audit findings were all label-vs-source mismatches: Dashboard "Blended Starlink IRR" pulled `=Starlink!F209` which was actually Forward IRR, because the rows had shifted three sprints earlier; Valuation "Live Group FCF" sourced from per-module FCFs (pre-tax) instead of Group FCF (post-tax). These bugs survived conservation checks because conservation operates on values, not on whether a label and a source agree about what concept they describe.

The label-based discipline extends to year-row formulas: every ramp uses the anchor-and-offset pattern (`$D$14 × (1+rate)^E$5`), never the recursive prior-column form (`E14 = D14 × (1+rate)`). Anchor-and-offset survives row moves. Recursive chains do not.

**Practical implication**: When you see a cell reference like `=ODC!D210`, that is a bug waiting to happen. Replace it with INDEX/MATCH on a canonical label. When you see `=E14 × (1+rate)`, that is a bug waiting to happen. Replace it with `$D$14 × (1+rate)^E$5`.

---

## Meta-lesson 8 — The Rule Compliance Preamble is a forcing function

The preamble is a 12-box checklist at the top of every spec. Each box references a specific rule (Rule 1 — one concept per write; Rule 4 — verification gate every section; Rule 12 — label-based cross-tab refs; etc.). The spec author ticks each box, justifies any N/A, and the plugin chat verifies the preamble is filled before executing a single cell write.

The preamble is not bureaucracy. It is a forcing function that makes Claude (in both spec-author and execution chats) explicitly confront every load-bearing discipline before it can take any other action. Boxes that are easy to tick mean the spec is well-formed. Boxes that are hard to tick — where the spec author has to justify an N/A — flag the parts of the spec that need more thinking.

The preamble also creates an audit trail. Every spec in the workspace folder opens with the same checklist; six months from now, anyone can scan a spec and tell whether it was written to the standard.

**Practical implication**: Never skip the preamble. Never leave a box unchecked without a justification. When the preamble feels onerous, that is the signal that the spec is shortcutting something the rules exist to prevent.

---

## The compounding effect

Each of these eight meta-lessons on its own gives you a small improvement. Stacked, they compound. The first build accumulated drift; the rebuild compounds discipline. Sprint 8 lands cleanly because Sprint 7 published its 7 canonical labels with verified IRR engines; Sprint 7 lands cleanly because Sprint 5 closed the ODC module with PASS on every anchor; Sprint 5 lands cleanly because Sprint 4 hit 14 of 15 calibration anchors and flagged the 15th with a fix scope already specified.

The rebuild is on track to close in roughly one third the calendar time of the first build, with a workbook we trust at the end of it. That is the value of treating the build as constitutional construction.

---

## What this means for the next model

When you start the next Mach33 model build (Portal, ASTS, the next SpaceX iteration once the IPO settles), the workflow is:

1. Read this doc.
2. Read `02_Bootstrap_Protocol.md` to understand what the five constitutional documents are.
3. Lock the architectural decisions for the new model with Vlad in a scoping conversation.
4. Draft the five constitutional documents using the templates in `06_Sprint_Spec_Template.md` and the reference docs in `reference/`.
5. Run Sprint 0 (architecture spec + Assumptions skeleton + tab list) as the first plugin sprint.
6. Then begin the module sprints, one at a time, each with a Rule Compliance Preamble and a verification gate at the end of every section.

The skill `mach33-model-build` (in `skills/`) automates the constitutional embedding — when triggered, it loads the 23 lessons, the 23 rules, and the architectural patterns directly into the active chat. Use it from the kickoff of every model-build chat.

---

## What we still do not know

The rebuild is not done. Specifically:

- **Vehicle build cost as forward-demand-sized non-module claim** — this architectural pattern (Sprint 9/10) is theoretically sound but not yet battle-tested at scale across the queue gate.
- **AI Stack as standalone module with internal at-cost compute from ODC** — locked in architecture, executed as scoping doc only; Stage 2 plugin execution still pending Vlad's sign-off on 8 open questions.
- **Round-trip stability under iterative calc with the full allocator circle live** — Sprint 5 tested ODC-only convergence; full-circle test happens at Sprint 10.
- **Monte Carlo discipline across 200+ inputs** — the MC input register is populated at row creation by rule, but the MC sprint itself has not yet run.

These four are the open principles that the next ~4 sprints will either validate or amend. When they land, this doc gets updated.

---

## How to use the rest of this folder

- **`02_Bootstrap_Protocol.md`** — what to do day one when starting a new model
- **`03_The_23_Lessons_Learned.md`** — the WHY (the principles, each tied to a V30.5 incident)
- **`04_Model_Execution_Rules.md`** — the operational HOW (the 23 plugin-side rules + the Rule Compliance Preamble)
- **`05_Architecture_Patterns.md`** — the architectural primitives (vending machine, allocator, per-sat IRR, anchor-and-offset, internal transfers)
- **`06_Sprint_Spec_Template.md`** — drop-in template for a new sprint spec, with the Rule Compliance Preamble pre-filled
- **`07_Calibration_and_Verification.md`** — calibration targets, halt thresholds, universal verification protocol
- **`08_Worked_Examples.md`** — case studies from Sprints 4, 5, 7, 8 — what was specced, what passed, what broke, what we did about it
- **`09_When_To_Rebuild_vs_Refine.md`** — the decision rule, with the V30.5 case as the canonical example
- **`skills/`** — the `mach33-model-build` skill, packaged for installation and reuse on the next model
- **`reference/`** — the full constitutional docs from the SpaceX rebuild, verbatim, as templates for the next model
