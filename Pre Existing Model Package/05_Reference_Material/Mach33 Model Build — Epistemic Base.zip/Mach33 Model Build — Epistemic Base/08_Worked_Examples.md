# Worked Examples — Sprints 4, 5, 7, 8

**Purpose**: Case studies from the SpaceX rebuild v2 showing how the protocol works in practice. Each sprint demonstrates a different pattern: PASS with a flagged retune, full PASS after absorbing the retune, PASS on a strategic-carve-out sprint with no IRR engine, and PASS-with-overshoot fully decomposed.

These are the templates colleagues should reach for when designing their own sprints. The structure (what was specced, what passed, what broke, what we did about it) is reusable for any module build.

---

## Sprint 4 — Starlink module + Starlink Capacity tab — PASS with one flagged retune

**Date executed**: 2026-05-20.
**Spec**: `Sprint_4_Spec.md` (~123KB).
**Tabs touched**: Starlink, Starlink Capacity, Assumptions (R314–R317 stub additions), Claude Log.
**Workbook**: V2.6.xlsx.

### What was specced

- Starlink module body: V2 BB + V2 DTC active fleet, launches, Wright's Law on bandwidth-per-sat (deferred for V3 to Sprint 4.5), ratchet flag for V3 BB introduction in 2026.
- Per-vehicle marginal IRR engines for V2 BB, V2 DTC, V3 BB, V3 DTC.
- Starlink Capacity tab: bandwidth supply, ODC bandwidth allocation pass-through (stub year-rows D316–D317), demand cap (deferred to Sprint 5 Demand Curves tab).
- Allocator OUT block with the 10 canonical Starlink + Starlink Capacity labels.

### What passed (14 of 15)

- Active V2 BB 5,246, V2 DTC 650, V3 0 (exact match to Q4'25 disclosure)
- V2 BB launches 2025 = 2,987; V2 DTC = 182; V3 = 0 (exact)
- Ratchet flag 2025 = 0; 2030 = 1 (V3 BB starts 2026 as designed)
- F9 V2 BB internal 103; V2 DTC internal 26 (Patch B Launch Capacity R64 now pulls 2025 F9 launches = 171, matches Sprint 2 calibration)
- Starshield revenue 2025 = $2,436M (target $2,520M, off 3.4% — within ±5%)
- Starlink+DTC 2025 = $7,853M (target $7,852M, exact)
- BB Revenue $7,696M; DTC $157M; BB subs 6.41M (in 5.5–7.5M target range)
- Module EBITDA margin 61.4% (in 55–75% target range)
- All 6 canonical Sprint 3 IFERROR-0 labels resolve cleanly
- All 10 canonical Starlink + Starlink Capacity labels resolve

### What broke (1 of 15)

- **Constellation D&A 2025 = $437M vs target $707M ±10% ([$636M, $778M]) — OUT of tolerance.**

### Root cause

Anticipated in spec §3.3.11. Formula reads only V2 BB + V2 DTC active mass, misses:
- Legacy V1/V1.5 D&A (~$130M) — still on books from earlier deployments
- Facility D&A (~$140M) — ground stations, network ops

### What we did about it

Flagged for Sprint 4.5 retune. Specifically:
1. Add legacy V1/V1.5 D&A as new Starlink tab row (or split into two memo rows).
2. Add facility D&A as a separate row.
3. Re-verify Constellation D&A 2025 against $707M ±10%.

Sprint 4.5 was absorbed into Sprint 5 prep (no separate sprint chat — Sprint 5 spec included the patch as §3.4 amendments).

### Out-year sanity (informational, not a halt)

- 2030 Total Revenue $125B; 2040 $238B; 2050 $238B.
- Supply-side revenue compounds linearly with V3 BB fleet (22,500 sats × 1,000 Gbps × ~$10,347/Gbps).
- No demand-side cap because Demand Curves tab missing (stub year-row is supply-feedstock pricing, not demand cap).
- Demand-side cap from proper Demand Curves tab (Sprint 5 prep) will likely compress out-year revenue substantially.

### Execution lessons (saved as separate memories)

- **INDEX col_num=0 spills** — modern Excel INDEX(range,1,0) returns whole row as spill; IFERROR doesn't catch; lookback formulas need IF(col<1,0,INDEX(...)) wrapper. (Saved as `feedback-index-col-zero-spills`.)
- **Iterative calc required** — Starlink ↔ Starlink Capacity % × Revenue creates a within-year cycle that needs iterative calc to converge. Enabled with 100 iter / 0.001 tol from Sprint 4 onward.

### Pattern this illustrates

PASS with one flagged retune is the most common sprint outcome. The discipline:
- Decompose the breach (formula-fixable vs architectural).
- Specify the retune scope before the next sprint.
- Verify the retune in the next sprint's prep, not in a separate "audit" pass.

---

## Sprint 5 — ODC module + absorbed Sprint 4.5 patch — full PASS

**Date executed**: 2026-05-20.
**Spec**: `Sprint_5_Spec.md` (~121KB).
**Tabs touched**: ODC, Demand Curves (new tab), Starlink (Sprint 4.5 patch), Assumptions, Claude Log.
**Workbook**: V2.7.xlsx.

### What was specced

- ODC module body: cash-driven deployment (NOT fixed stub year-row), per-sat marginal IRR engine, dual revenue model (Model A energy-anchored + Model B η/compute-anchored, Pr(B) = 0.6 credence weight).
- Bandwidth claim on Starlink (BB + DTC at-cost based on compute energy × Gbps/GWh conversion factor).
- ODC at-cost compute rate published for Sprint 6 AI Stack to consume.
- Sprint 4.5 patch absorbed: V3 BB Wright's Law on bandwidth-per-sat (cum-sats running sum), Constellation D&A legacy + facility additions, Demand Curves tab build.
- 5 canonical ODC OUT labels for downstream consumers.

### What passed (every anchor)

**§6.4 ODC calibration — all PASS**:
- ODC revenue 2025 = $0 exact
- ODC sats deployed 2025 = 0 exact
- ODC fleet end-2025 = 0 exact
- Per-sat Blended IRR 2025 = −29.7% (real number, < 0, NOT IFERROR -100% fallback)
- Bandwidth services cost paid to Starlink 2025 = $0 exact
- At-cost compute rate 2025 = $0 (IFERROR for fleet=0; resolves cleanly downstream for Sprint 6 AI Stack reads)

**Sprint 4.5 patch calibration — all PASS**:
- Starlink+DTC revenue 2025 = $7,853M (Sprint 4 anchor $7,852M ±5%) ✓
- Constellation D&A 2025 = $706.66M (target $707M ±10%) ✓
- V3 BB Gbps/sat: 2025 = 1,000 exact, 2030 = 1,876, 2050 = 2,582 ✓ (WL active with cum-sats running sum)
- Demand Curves tab live at sheet position #14 with four canonical year-rows

**Five canonical labels published — all downstream IFERROR-0 reads resolve cleanly**:
- ODC R54 `ODC Starship launches (internal)` → CL R69 = 0 ✓
- ODC R55 `ODC Starship kg demand` → CL R22 = 0 ✓
- ODC R81 `ODC BB Gbps demand` → SLC R18 = 0 ✓
- ODC R82 `ODC DTC Gbps demand` → SLC R20 = 0 ✓
- ODC R113 `ODC at-cost compute rate ($/PFLOP-hr)` published for Sprint 6 AI Stack

### 8 amendments accumulated in spec §9

The Sprint 5 spec accumulated 8 amendments during execution — small additions that didn't break scope but added clarity. These are tracked in §9 of the spec and rolled into the architecture spec at the next refresh. The discipline: always note amendments in §9 of the executing spec, never silently change the architecture mid-sprint.

### Pre-existing Sprint 3 bug surfaced

Customer Launch G16:AC16 #N/A — inherited from Sprint 3, not Sprint 5's fault. Flagged for Sprint 3.6 micro-patch. (Eventually resolved in Sprint 8 §3.1 by adding Assumptions R342 `Starship customer launch margin — CAGR` = −4.17%/yr.)

### Pattern this illustrates

Full PASS after absorbing a prior-sprint retune. The discipline:
- Patches don't get their own sprint chat unless they're large enough to warrant one. Absorb into the next sprint's prep.
- §9 amendments capture small in-flight refinements without breaking the spec's scope contract.
- Pre-existing bugs from upstream sprints get surfaced but not silently fixed — flag them as their own patch sprint to keep diff isolation.

---

## Sprint 7 — Lunar Mars module + strategic carve-out + BV engine — PASS (no IRR engine)

**Date executed**: 2026-05-22.
**Spec**: `Sprint_7_Spec.md` (~95KB).
**Tabs touched**: Lunar Mars (rows 11–139 body + R201–R212 OUT overwrite), Allocator (§3 carve-out section R32–R37), Assumptions (R339/R340/R341 new amendments + R226/R227 year-row stub fill + R217/R221 LEGACY flags), Claude Log.

### What was specced

- Lunar Mars module body: strategic carve-out cash claim, BV engine (labour units + hardware methodology from Sprint 4 / Q4'25), Lunar/Mars share trajectory (70/30 from 2028+), Mars carve-out 15% / $1B floor.
- Allocator §3 carve-out section: deducts carve-out from cash pool BEFORE IRR queue runs.
- 7 canonical labels published (5 OUT + 2 BV memos for Sprint 11 SoTP terminal).
- Per-mission IRR engine deferred (R207/R208/R209 hardcoded literal `=0`).
- OpEx Mars/Moon R&D NOT on this tab (Rule 13 — lives on OpEx tab; Sprint 8 owns it).

### What passed (every §6.6 halt threshold hit exact in 2025)

- Lunar Mars Revenue 2025 = $0 ✓
- Mission CapEx 2025 = $0 ✓
- Lunar BV 2025 = $0 ✓
- Mars BV 2025 = $0 ✓
- Module FCF 2025 = $0 ✓

### Out-year trajectory (informational)

- 2028 first missions: 7 Lunar surface + 1 Mars surface landings
- Kg reserved off-top: D=0 → G=3.3M kg → AC=4.4M kg/yr
- 2050: Lunar BV = $137B, Mars BV = $41B, Total = $178B
- Sprint 11 SoTP terminal anchor (× 1.5 multiplier) = $266B
- Module FCF stays heavily negative (~$1B/yr) — pre-revenue throughout horizon as designed

### Architectural decisions locked 2026-05-20 (in Sprint 7 prep)

1. Mars carve-out Base Case: 15% / $1,000M floor (Sprint 0 R12/R13 unchanged)
2. Lunar / Mars share trajectory: 100% Lunar pre-2028, **70% Lunar / 30% Mars from 2028+** (Vlad: focus shifting to Moon/Lunar over Mars vs first iteration; naming retained as "Mars carve-out" per Principle 7 — no renames)
3. Labour share trajectory: year-row 0.3 → 0.7 ramp (NEW Assumptions amendments R339/R340)
4. Per-mission IRR engine: deferred. R207/R208/R209 hardcoded literal `=0`
5. BV memo labels: Sprint 1 verbatim retained
6. OpEx Mars/Moon R&D: Sprint 8 owns (NOT on Lunar Mars tab — Rule 13)
7. Hardware $/kg: Sprint 0 R225 year-row as-is (declining profile, $1,000 → $300)

### NEW Assumptions amendments added 2026-05-22

- R339 `Lunar labour share of surface payload — year-row` (D=0.3 → AC=0.7, MC triangle-yearrow [0.1, 0.7])
- R340 `Mars labour share of surface payload — year-row` (same trajectory)
- R341 `First mission year (Lunar Mars)` (=2028, MC discrete [2026, 2032]) — calibration-forced gate per Q4'25 anchor "Mars & Moon mission cash spend 2025 = $0"
- R217 + R221 single-value labour shares flagged `[LEGACY — Sprint 7 superseded]` in column C (orphan, BV engine reads new year-rows)
- R226 + R227 year-row stubs filled per Vlad lock (Lunar 100%/100%/100%/70% → /70%, Mars derived = 1 − R226)

### Open threads carried forward

1. **Carve-out vs Module CapEx gap pre-2028** (memo R134 = $1B/yr 2025–2027 reserved but not spent) — Sprint 9/10 cash flow identity needs to decide drain vs reserve treatment.
2. **Architecture §11.4 "ships deployed / (1+depot)" ambiguity** — Sprint 7 interpreted "ships deployed" = surface missions throughout. §11.4 division by (1+depot) would understate surface landings. Pre-Sprint-9 Architecture refresh recommended.
3. **Customer Launch G16:AC16 #N/A** — Sprint 3.6 micro-patch awaiting (NOW BLOCKING for Sprint 8).

### Pattern this illustrates

PASS on a strategic carve-out sprint with no IRR engine. The discipline:
- Strategic carve-outs deduct cash from the pool BEFORE the IRR queue runs.
- No IRR engine means R207/R208/R209 are hardcoded `=0` literals (not IFERROR computations).
- BV engine for terminal value, not IRR for cash allocation.
- Halt thresholds: pre-revenue years should be exactly $0, not "approximately zero." Exact matching catches the "deployment leak" failure mode (e.g., a small Mars mission accidentally starting in 2025).

---

## Sprint 8 — OpEx + CapEx tabs + absorbed Sprint 3.6 patch — PASS-with-overshoot

**Date executed**: 2026-05-22.
**Spec**: `Sprint_8_Spec.md` (~70KB).
**Tabs touched**: OpEx (rows 10–60), CapEx (rows 10–47), Assumptions (R342 Sprint 3.6 patch + R343 ODC R&D $-profile + R344 AI Stack R&D $-profile), Customer Launch (cascade cleared via R342 patch; no direct writes), Claude Log.

### What was specced

- OpEx tab: R&D (Starlink, Customer Launch, ODC, AI Stack, Mars/Moon), SG&A, customer service. Every module's overhead lives here, not on module tabs (Rule 13).
- CapEx tab: Module CapEx aggregation + corporate CapEx + spectrum amortization. Vehicle build cost = $0 placeholder (Sprint 10 lights up the Allocator queue gate claim).
- Sprint 3.6 absorbed §3.1: new Assumptions R342 `Starship customer launch margin — CAGR (% change/yr from 2027 anchor)` = `(1.5/4)^(1/23)-1` ≈ −4.17%/yr, MC triangle [−6%, −2%].

### What passed

| Line | Actual | Target | Delta | Status |
|---|---|---|---|---|
| Starlink R&D | $868M | $830M | +4.6% | ✓ |
| Customer Launch R&D | $1,071M | $1,073M | 0% | ✓ |
| ODC R&D (floor) | $200M | $200M | 0% | ✓ |
| AI Stack R&D (floor) | $50M | $50M | 0% | ✓ |
| Mars/Moon R&D | $700M | $700M | 0% | ✓ |
| **Total R&D** | **$2,889M** | **$2,853M** | **+1.3%** | **✓** |
| S&M | $605M | $586M | +3% | ✓ |
| Total Corporate CapEx | $110M | $110M | 0% | ✓ |
| Spectrum amort | $333M | $333M | 0% | ✓ |
| Total Group CapEx | $6,345M | $7,030M | −10% | ✓ (vehicle build $0 placeholder; Sprint 10 lights up) |

Sprint 3.6 micro-patch landed clean: Customer Launch G16:AC16 #N/A → cleared (G16 ≈ 3.833, AC16 ≈ 1.5). R201 Total Revenue 2028+ + R205 Module CapEx 2030+ cascade clean.

### What overshot (two breaches, both decomposed)

| Line | Actual | Target | Delta | Status |
|---|---|---|---|---|
| **G&A** | **$871M** | **$733M** | **+19%** | **⚠ overshoot** |
| **CS** | **$217M** | **$157M** | **+38%** | **⚠ Starshield overcount** |
| Other | $174M | $147M | +18% | ⚠ internal flow overcount |
| **Total SG&A** | **$1,868M** | **$1,623M** | **+15%** | **⚠** |
| **Total OpEx** | **$4,757M** | **$3,820M** | **+24.5%** | **❌ HALT THRESHOLD TRIPPED** |
| **Total Module CapEx** | **$1,235M** | **$2,030M** | **−39%** | **❌ HALT THRESHOLD TRIPPED** |

### Breach 1 — Total OpEx +$937M overshoot, fully decomposed

- **$226M genuinely fixable (Sprint 8.5 retune)**:
  - CS Starshield overcount: $60M (CS reads Starlink R201 incl. Starshield; should read BB+DTC subscription only)
  - G&A R57 group rev memo overcount: $138M (memo sums 5 module R201s; Customer Launch R201 = $6,572M includes $2,290M internal transfer revenue; needs subtraction)
  - Other R57 same overcount: $28M
- **$711M architectural / Q4'25 anchor divergence (NOT fixable in 8.5)**:
  - $250M pre-revenue R&D floors (ODC $200M + AI Stack $50M — Architecture §12.1 amendment 2026-05-20, legitimate additions)
  - ~$461M rate × base differences (Sprint 0 R&D + SG&A rates applied to current revenue bases exceed Q4'25's flat $3,820M anchor)
- **Recommendation**: Update Roadmap §6.7 Total OpEx target $3,820M → ~$4,531M (post-Sprint-8.5) reflecting current architecture + Architecture §12 amendments

### Breach 2 — Total Module CapEx −$795M undershoot

- ARCHITECTURAL — Q4'25 anchor $2,030M included F9 vehicle build in Customer Launch Module CapEx (~$850M for 17 boosters × ~$50M)
- Rebuild architecture §6.6 moved vehicle build to Allocator queue gate (Sprint 10 lights up). CapEx tab R44 placeholder = $0 in Sprint 8.
- Post-Sprint-10 Vehicle build claim ≈ $800M → Total Group CapEx $6,345M + $800M ≈ $7,145M ≈ $7,030M target ±5% ✓
- **Recommendation**: Update Roadmap §6.7 Module CapEx target $2,030M → ~$1,235M (vehicle build excluded per Architecture §6.6); Group CapEx target $7,030M still holds post-Sprint-10

### Sprint 8.5 retune scope

1. **OpEx R48 CS formula rewrite** — read Starlink subscription rev directly:
   ```
   =INDEX(Starlink!$D:$AC, MATCH("BB Revenue ($mm)", Starlink!$A:$A, 0), D$5+1)
   + INDEX(Starlink!$D:$AC, MATCH("DTC Revenue ($mm)", Starlink!$A:$A, 0), D$5+1)
   ```
   Expected D48 post-fix: 2% × $7,853M = $157M ✓ matches target

2. **OpEx R57 Group rev memo subtract internal transfer revenue**:
   ```
   − INDEX('Customer Launch'!$D:$AC, MATCH("Customer Launch internal transfer revenue ($mm)", 'Customer Launch'!$A:$A, 0), D$5+1)
   ```
   Expected D57 post-fix: $17,426M − $2,290M = $15,136M
   G&A post-fix: 5% × $15,136M = $757M ✓
   Other post-fix: 1% × $15,136M = $151M ✓

3. **Post-fix expected Total OpEx**: $4,757M − $60M − $114M − $23M = $4,560M
   - Still ~19% above Q4'25 raw $3,820M anchor, but architecturally explained
   - Recommend Vlad accept revised target $4,476M ±5% [$4,250M, $4,700M]

4. **Roadmap §6.7 calibration target update** — amend the doc to:
   - Total OpEx target $3,820M → $4,476M (rebuild architecture)
   - Total Module CapEx target $2,030M → $1,235M (vehicle build at Allocator)
   - Group CapEx target $7,030M unchanged

### Pattern this illustrates

PASS-with-overshoot fully decomposed. The discipline:
- Don't treat a calibration breach as "model broken." Decompose into fixable vs architectural.
- Fixable portion → patch sprint (8.5) with the specific formula corrections.
- Architectural portion → update the anchor table in the architecture spec, with documented justification.
- Never "audit later." A breach that is decomposed and addressed in the next sprint is acceptable; a breach left unexplained is the V30.5 failure mode.

---

## Summary — what these four sprints teach

| Pattern | Sprint | What to take away |
|---|---|---|
| PASS with one flagged retune | 4 | Most common sprint outcome. Decompose breach, specify retune scope, verify in next sprint's prep. |
| Full PASS after absorbing retune | 5 | Patches don't always need their own sprint chat. Absorb into next sprint's prep. §9 amendments capture small in-flight refinements. |
| PASS on strategic carve-out (no IRR engine) | 7 | Strategic carve-outs deduct cash before queue. Exact-zero halt thresholds for pre-revenue years catch deployment leaks. |
| PASS-with-overshoot fully decomposed | 8 | Decompose breach into fixable vs architectural. Patch the fixable. Update anchors for architectural. Never "audit later." |

These four cover roughly 90% of sprint outcomes. The remaining 10% are:
- True FAIL — spec is wrong, plugin halts mid-sprint. Iterate the spec, re-run.
- PASS-with-deferral — a non-blocking open thread is flagged for a future sprint (e.g., Sprint 7's three open threads carried to Sprint 9/10).

---

## Related

- `06_Sprint_Spec_Template.md` — drop-in template structured for the PASS / PASS-with-overshoot patterns
- `07_Calibration_and_Verification.md` — the universal verification protocol these sprints run
- `09_When_To_Rebuild_vs_Refine.md` — the decision rule that brought us here
- Sprint specs themselves (in the SpaceX project folder): `Sprint_4_Spec.md`, `Sprint_5_Spec.md`, `Sprint_7_Spec.md`, `Sprint_8_Spec.md`, `Sprint_8.5_Patch.md`
